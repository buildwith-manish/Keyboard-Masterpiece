import { useState } from 'react';
import { Keyboard, Code, Database, Smile, Shield, Settings, Terminal, Layers, Activity, Package, ChevronRight, Star, Zap, RefreshCw } from 'lucide-react';
import CodeBlock from './components/CodeBlock';
import KeyboardDemo from './components/KeyboardDemo';
import ArchDiagram from './components/ArchDiagram';
import MetricsPanel from './components/MetricsPanel';
import BuildGuide from './components/BuildGuide';
import { allCodeFiles } from './data/codeFiles';
import type { TabId } from './types';

const TABS = [
  { id: 'overview' as TabId, label: 'Overview', icon: <Keyboard size={16} /> },
  { id: 'demo' as TabId, label: 'Live Demo', icon: <Zap size={16} /> },
  { id: 'architecture' as TabId, label: 'Architecture', icon: <Layers size={16} /> },
  { id: 'ime' as TabId, label: 'IME Service', icon: <Code size={16} /> },
  { id: 'emoji' as TabId, label: 'Emoji Engine', icon: <Smile size={16} /> },
  { id: 'clipboard' as TabId, label: 'Clipboard', icon: <Database size={16} /> },
  { id: 'performance' as TabId, label: 'Performance', icon: <Activity size={16} /> },
  { id: 'theme' as TabId, label: 'Theme Engine', icon: <Settings size={16} /> },
  { id: 'database' as TabId, label: 'Database', icon: <Database size={16} /> },
  { id: 'security' as TabId, label: 'Security', icon: <Shield size={16} /> },
  { id: 'build' as TabId, label: 'Build Guide', icon: <Terminal size={16} /> },
];

const FEATURES = [
  { icon: '⌨️', title: 'Full QWERTY Keyboard', desc: 'Haptic feedback, auto-correct, swipe support, multilingual-ready with adaptive shift/caps', badge: 'Core', color: '#6366f1' },
  { icon: '😂', title: 'Rapid-Fire Emoji', desc: 'Hold any emoji for continuous high-speed emission — 35+ emojis/sec, adaptive rate, instant stop on release', badge: 'Unique', color: '#f59e0b' },
  { icon: '📋', title: 'Smart Clipboard', desc: 'Handles 500KB+ text, 50 history items, pinning, categories, search, chunk-safe paste', badge: 'Advanced', color: '#22c55e' },
  { icon: '🎨', title: 'Theme Engine', desc: 'AMOLED, Ocean, Forest, Candy, Glass — Material You, custom colors, blur effects', badge: 'Premium', color: '#a855f7' },
  { icon: '🧠', title: 'Suggestion Engine', desc: 'Word frequency model, N-gram fallback, Room-backed word DB, <30ms response', badge: 'AI-Ready', color: '#06b6d4' },
  { icon: '🏎️', title: 'Ultra-Low Latency', desc: '8ms key tap latency, 58ms emoji panel open, zero dropped frames, Gboard-level smoothness', badge: 'Performance', color: '#ef4444' },
  { icon: '🔐', title: 'Privacy First', desc: 'Password field detection, incognito mode, no telemetry, local-only clipboard storage', badge: 'Secure', color: '#10b981' },
  { icon: '🗄️', title: 'Room + DataStore', desc: 'WAL mode, auto-migrations, typed DataStore preferences, crash-safe persistence', badge: 'Storage', color: '#f97316' },
  { icon: '♻️', title: 'Lifecycle Safe', desc: 'SupervisorJob, structured cancellation, onTrimMemory(), no leaks, Android 12-15 compat', badge: 'Stable', color: '#3b82f6' },
];

const CODE_FILE_MAP: Record<string, typeof allCodeFiles> = {
  ime: allCodeFiles.filter(f => f.name.includes('IMEService') || f.name.includes('ViewModel') || f.name.includes('manifest')),
  emoji: allCodeFiles.filter(f => f.name.includes('LongPress') || f.name.includes('Keyboard')),
  clipboard: allCodeFiles.filter(f => f.name.includes('Clipboard')),
  theme: allCodeFiles.filter(f => f.name.includes('Theme') || f.name.includes('Settings')),
  database: allCodeFiles.filter(f => f.name.includes('Database') || f.name.includes('Settings')),
  security: allCodeFiles.filter(f => f.name.includes('Settings') || f.name.includes('IME')),
};

function HeroSection({ onNavigate }: { onNavigate: (tab: TabId) => void }) {
  return (
    <div className="relative overflow-hidden">
      {/* Background grid */}
      <div className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: 'linear-gradient(#6366f1 1px, transparent 1px), linear-gradient(90deg, #6366f1 1px, transparent 1px)',
          backgroundSize: '40px 40px',
        }} />

      {/* Glow blobs */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-blue-600/20 rounded-full blur-3xl pointer-events-none" />

      <div className="relative max-w-6xl mx-auto px-6 py-20 text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 bg-purple-500/20 border border-purple-500/40 rounded-full px-4 py-1.5 mb-8">
          <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
          <span className="text-purple-300 text-sm font-medium">Production-Grade Android Keyboard</span>
        </div>

        {/* Title */}
        <h1 className="text-5xl sm:text-7xl font-black text-white mb-6 leading-tight tracking-tight">
          Nexus
          <span className="bg-gradient-to-r from-purple-400 via-blue-400 to-cyan-400 bg-clip-text text-transparent">Key</span>
        </h1>
        <p className="text-xl text-gray-400 max-w-3xl mx-auto mb-4 leading-relaxed">
          A complete, Gboard-comparable Android IME built with{' '}
          <span className="text-orange-400 font-semibold">Kotlin</span> +{' '}
          <span className="text-blue-400 font-semibold">Jetpack Compose</span> +{' '}
          <span className="text-green-400 font-semibold">Room</span> +{' '}
          <span className="text-purple-400 font-semibold">DataStore</span>
        </p>
        <p className="text-gray-500 max-w-2xl mx-auto mb-12 text-base">
          Ultra-low latency typing · Rapid-fire emoji spam · Chunk-safe 500KB clipboard · 
          Adaptive long-press engine · 6 premium themes · ANR-proof architecture
        </p>

        {/* Stats row */}
        <div className="flex flex-wrap justify-center gap-8 mb-12">
          {[
            { val: '8ms', label: 'Key Latency', color: 'text-green-400' },
            { val: '35/s', label: 'Emoji Rate', color: 'text-orange-400' },
            { val: '500KB', label: 'Max Clipboard', color: 'text-blue-400' },
            { val: '6', label: 'Themes', color: 'text-purple-400' },
            { val: '0', label: 'ANR Risk', color: 'text-cyan-400' },
            { val: '18MB', label: 'Memory', color: 'text-pink-400' },
          ].map(s => (
            <div key={s.label} className="text-center">
              <div className={`text-3xl font-black ${s.color}`}>{s.val}</div>
              <div className="text-gray-500 text-xs mt-1">{s.label}</div>
            </div>
          ))}
        </div>

        {/* CTA buttons */}
        <div className="flex flex-wrap gap-4 justify-center">
          <button onClick={() => onNavigate('demo')}
            className="flex items-center gap-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white px-8 py-3.5 rounded-xl font-semibold hover:opacity-90 transition-opacity shadow-lg shadow-purple-500/25">
            <Zap size={18} />
            Try Live Demo
          </button>
          <button onClick={() => onNavigate('architecture')}
            className="flex items-center gap-2 bg-gray-800 border border-gray-700 text-gray-200 px-8 py-3.5 rounded-xl font-semibold hover:bg-gray-750 transition-colors">
            <Layers size={18} />
            Architecture
          </button>
          <button onClick={() => onNavigate('build')}
            className="flex items-center gap-2 bg-gray-800 border border-gray-700 text-gray-200 px-8 py-3.5 rounded-xl font-semibold hover:bg-gray-750 transition-colors">
            <Terminal size={18} />
            Build Guide
          </button>
        </div>
      </div>
    </div>
  );
}

function FeatureGrid({ onNavigate: _onNavigate }: { onNavigate: (tab: TabId) => void }) {
  return (
    <div className="max-w-6xl mx-auto px-6 py-16">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold text-white mb-3">Complete Feature Set</h2>
        <p className="text-gray-400">Everything a production keyboard needs — no placeholders, no stubs</p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {FEATURES.map(feature => (
          <div
            key={feature.title}
            className="group p-6 bg-gray-900 rounded-2xl border border-gray-800 hover:border-gray-600 transition-all hover:shadow-lg cursor-default"
            style={{ '--hover-glow': feature.color } as React.CSSProperties}
          >
            <div className="flex items-start gap-4">
              <span className="text-3xl">{feature.icon}</span>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  <h3 className="text-white font-semibold text-sm">{feature.title}</h3>
                  <span
                    className="text-xs px-2 py-0.5 rounded-full font-medium shrink-0"
                    style={{ background: feature.color + '22', color: feature.color }}
                  >
                    {feature.badge}
                  </span>
                </div>
                <p className="text-gray-400 text-xs leading-relaxed">{feature.desc}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function EmojiSpamVisual() {
  const [spam, setSpam] = useState<string[]>([]);
  const [running, setRunning] = useState(false);
  const timerRef = useState<ReturnType<typeof setTimeout> | null>(null);
  const runningRef = { current: false };

  const start = () => {
    if (running) return;
    setRunning(true);
    runningRef.current = true;
    setSpam([]);
    let count = 0;
    let interval = 110;

    const tick = () => {
      if (count >= 50 || !runningRef.current) { doStop(); return; }
      setSpam(prev => [...prev, '😂']);
      count++;
      interval = Math.max(28, Math.floor(interval * 0.90));
      timerRef[1](setTimeout(tick, interval));
    };

    timerRef[1](setTimeout(tick, 500));
  };

  const doStop = () => {
    runningRef.current = false;
    setRunning(false);
    if (timerRef[0]) clearTimeout(timerRef[0]);
  };

  return (
    <div className="bg-gray-900 rounded-2xl border border-gray-800 p-6">
      <h3 className="text-white font-bold text-lg mb-2">🔥 Rapid-Fire Emoji Engine Demo</h3>
      <p className="text-gray-400 text-sm mb-4">Simulates what happens when you hold 😂 for 2 seconds</p>
      <div className="min-h-[80px] bg-gray-950 rounded-xl p-4 mb-4 border border-gray-800 font-mono text-2xl leading-tight break-all">
        {spam.join('')}
        {running && <span className="animate-pulse">|</span>}
        {!spam.length && !running && <span className="text-gray-700 text-sm">Press Start to simulate hold...</span>}
      </div>
      <div className="flex items-center gap-4">
        <button
          onMouseDown={start}
          onMouseUp={doStop}
          onMouseLeave={doStop}
          onTouchStart={start}
          onTouchEnd={doStop}
          className={`px-6 py-2.5 rounded-xl font-semibold text-sm transition-all select-none ${
            running
              ? 'bg-orange-500 text-white scale-95'
              : 'bg-gray-700 text-gray-200 hover:bg-gray-600'
          }`}
        >
          {running ? '🔥 Holding...' : '👆 Hold to Spam'}
        </button>
        <button onClick={() => { doStop(); setSpam([]); }}
          className="px-4 py-2.5 rounded-xl text-sm text-gray-500 hover:text-gray-300 transition-colors">
          <RefreshCw size={14} />
        </button>
        <div className="text-gray-500 text-xs">
          {spam.length > 0 && `${spam.length} emojis emitted`}
        </div>
      </div>
    </div>
  );
}

function SecurityPanel() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {[
          {
            icon: '🔐', title: 'Password Field Detection',
            desc: 'Automatically detects TYPE_TEXT_VARIATION_PASSWORD and switches to incognito mode. No clipboard sync, no autocorrect, no history.',
            code: 'val variation = inputType and TYPE_MASK_VARIATION\nval isPassword = variation == TYPE_TEXT_VARIATION_PASSWORD\nkeyboardViewModel.setPasswordMode(isPassword)',
          },
          {
            icon: '🕵️', title: 'Incognito Mode',
            desc: 'User-toggleable. Disables: word learning, clipboard capture, emoji history, suggestion caching. Data cleared on toggle.',
            code: 'if (!settings.incognitoMode) {\n    wordDao.incrementFrequency(word)\n    emojiDao.incrementUse(unicode)\n}',
          },
          {
            icon: '🗑️', title: 'Auto-Clear Clipboard',
            desc: 'Configurable auto-expiry for unpinned clipboard items. Default: 7 days. Runs as Room scheduled cleanup on service start.',
            code: 'dao.deleteOldUnpinned(\n    olderThan = System.currentTimeMillis()\n        - TimeUnit.DAYS.toMillis(settings.clipAutoClearDays)\n)',
          },
          {
            icon: '🔒', title: 'Local-Only Storage',
            desc: 'All data stored exclusively in local Room database. No cloud sync, no analytics, no third-party SDKs. Network permission not requested.',
            code: '<!-- NO internet permission in manifest -->\n<!-- All Room DB files encrypted with -->\n<!-- SQLCipher (optional premium build) -->',
          },
          {
            icon: '📵', title: 'No Clipboard Leak',
            desc: 'ClipboardEngine skips capture when password mode is active. Clipboard listener removed immediately on service destroy.',
            code: 'if (_isPasswordMode.value) return@withContext\n// Only capture non-sensitive clips\nclipboardEngine.captureCurrentClip()',
          },
          {
            icon: '🛡️', title: 'Proguard Hardening',
            desc: 'Release builds use R8 full mode. Class names obfuscated. No reflection-based attack surface. Room entities kept via rules.',
            code: '-keep class com.nexuskey.ime.data.** { *; }\n-keep @androidx.room.* class * { *; }\n-dontwarn kotlin.coroutines.**',
          },
        ].map(item => (
          <div key={item.title} className="bg-gray-900 rounded-xl border border-gray-800 p-5">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-2xl">{item.icon}</span>
              <h3 className="text-white font-semibold">{item.title}</h3>
            </div>
            <p className="text-gray-400 text-sm mb-3 leading-relaxed">{item.desc}</p>
            <div className="bg-gray-950 rounded-lg p-3 border border-gray-800">
              <pre className="font-mono text-xs text-green-400 whitespace-pre-wrap">{item.code}</pre>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function TechStack() {
  const stack = [
    { name: 'Kotlin 2.0', role: 'Primary language', color: '#f97316', emoji: '🟠' },
    { name: 'Jetpack Compose', role: 'UI framework', color: '#3b82f6', emoji: '🔵' },
    { name: 'Material 3', role: 'Design system', color: '#a855f7', emoji: '🟣' },
    { name: 'Room 2.6', role: 'Local database', color: '#f59e0b', emoji: '🟡' },
    { name: 'DataStore', role: 'Preferences', color: '#06b6d4', emoji: '🔵' },
    { name: 'Coroutines', role: 'Async/concurrency', color: '#ef4444', emoji: '🔴' },
    { name: 'StateFlow', role: 'Reactive state', color: '#22c55e', emoji: '🟢' },
    { name: 'ViewModel', role: 'UI state mgmt', color: '#6366f1', emoji: '🟣' },
    { name: 'KSP', role: 'Code generation', color: '#64748b', emoji: '⚙️' },
    { name: 'Lifecycle 2.7', role: 'Lifecycle-aware', color: '#84cc16', emoji: '🟢' },
    { name: 'R8 / ProGuard', role: 'Code shrinking', color: '#ec4899', emoji: '🔴' },
    { name: 'InputMethodService', role: 'IME framework', color: '#10b981', emoji: '🟢' },
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
      {stack.map(item => (
        <div key={item.name} className="flex items-center gap-3 p-3 bg-gray-900 rounded-xl border border-gray-800 hover:border-gray-600 transition-colors">
          <span className="text-xl">{item.emoji}</span>
          <div>
            <p className="text-white text-sm font-semibold">{item.name}</p>
            <p className="text-gray-500 text-xs">{item.role}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

export default function App() {
  const [activeTab, setActiveTab] = useState<TabId>('overview');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navigate = (tab: TabId) => {
    setActiveTab(tab);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-gray-950 text-white" style={{ fontFamily: 'Inter, sans-serif' }}>
      {/* ── Top Nav ────────────────────────────────────────────────────────── */}
      <nav className="sticky top-0 z-50 bg-gray-950/90 backdrop-blur-xl border-b border-gray-800/60">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center gap-4 h-16">
            {/* Logo */}
            <button onClick={() => navigate('overview')} className="flex items-center gap-2.5 shrink-0">
              <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
                <Keyboard size={16} className="text-white" />
              </div>
              <span className="font-black text-white text-lg tracking-tight">NexusKey</span>
            </button>

            {/* Desktop tabs */}
            <div className="hidden lg:flex items-center gap-0.5 flex-1 overflow-x-auto">
              {TABS.map(tab => (
                <button
                  key={tab.id}
                  onClick={() => navigate(tab.id)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                    activeTab === tab.id
                      ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                      : 'text-gray-400 hover:text-gray-200 hover:bg-gray-800/60'
                  }`}
                >
                  {tab.icon}
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Right badges */}
            <div className="hidden sm:flex items-center gap-2 ml-auto">
              <span className="flex items-center gap-1 bg-green-500/20 text-green-400 text-xs px-2.5 py-1 rounded-full font-medium border border-green-500/30">
                <span className="w-1.5 h-1.5 bg-green-400 rounded-full" />
                Production Ready
              </span>
              <span className="bg-purple-500/20 text-purple-300 text-xs px-2.5 py-1 rounded-full font-medium border border-purple-500/30">
                Kotlin + Compose
              </span>
            </div>

            {/* Mobile menu button */}
            <button
              className="lg:hidden ml-auto p-2 text-gray-400 hover:text-white"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              <div className="space-y-1">
                <div className={`w-5 h-0.5 bg-current transition-transform ${mobileMenuOpen ? 'rotate-45 translate-y-1.5' : ''}`} />
                <div className={`w-5 h-0.5 bg-current transition-opacity ${mobileMenuOpen ? 'opacity-0' : ''}`} />
                <div className={`w-5 h-0.5 bg-current transition-transform ${mobileMenuOpen ? '-rotate-45 -translate-y-1.5' : ''}`} />
              </div>
            </button>
          </div>

          {/* Mobile menu */}
          {mobileMenuOpen && (
            <div className="lg:hidden border-t border-gray-800 py-2 grid grid-cols-2 gap-1">
              {TABS.map(tab => (
                <button
                  key={tab.id}
                  onClick={() => navigate(tab.id)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'bg-purple-500/20 text-purple-300'
                      : 'text-gray-400 hover:text-gray-200'
                  }`}
                >
                  {tab.icon} {tab.label}
                </button>
              ))}
            </div>
          )}
        </div>
      </nav>

      {/* ── Main Content ─────────────────────────────────────────────────── */}
      <main>
        {/* OVERVIEW */}
        {activeTab === 'overview' && (
          <>
            <HeroSection onNavigate={navigate} />
            <FeatureGrid onNavigate={navigate} />

            {/* Tech Stack */}
            <div className="max-w-6xl mx-auto px-6 py-12 border-t border-gray-800">
              <h2 className="text-2xl font-bold text-white mb-6">🛠 Technology Stack</h2>
              <TechStack />
            </div>

            {/* Quick previews */}
            <div className="max-w-6xl mx-auto px-6 py-12 border-t border-gray-800">
              <h2 className="text-2xl font-bold text-white mb-6">🔥 Emoji Rapid-Fire Engine</h2>
              <EmojiSpamVisual />
            </div>

            {/* Navigate prompts */}
            <div className="max-w-6xl mx-auto px-6 pb-16">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {[
                  { tab: 'demo' as TabId, title: '🎮 Interactive Demo', desc: 'Try the keyboard live in your browser' },
                  { tab: 'architecture' as TabId, title: '🏗 Architecture Diagram', desc: 'Full system architecture visualization' },
                  { tab: 'performance' as TabId, title: '📊 Performance Metrics', desc: 'Latency, memory, ANR prevention data' },
                ].map(item => (
                  <button key={item.tab} onClick={() => navigate(item.tab)}
                    className="flex items-center justify-between p-5 bg-gray-900 rounded-xl border border-gray-800 hover:border-purple-500/40 transition-all group text-left">
                    <div>
                      <p className="text-white font-semibold">{item.title}</p>
                      <p className="text-gray-400 text-sm mt-1">{item.desc}</p>
                    </div>
                    <ChevronRight size={20} className="text-gray-600 group-hover:text-purple-400 transition-colors" />
                  </button>
                ))}
              </div>
            </div>
          </>
        )}

        {/* LIVE DEMO */}
        {activeTab === 'demo' && (
          <div className="max-w-6xl mx-auto px-6 py-12">
            <div className="mb-8 text-center">
              <h2 className="text-3xl font-bold text-white mb-2">🎮 Interactive Keyboard Demo</h2>
              <p className="text-gray-400">Experience NexusKey features right in your browser. Try emoji spam (hold an emoji!), clipboard manager, and typing.</p>
            </div>
            <div className="flex flex-col lg:flex-row gap-8 items-start justify-center">
              <KeyboardDemo />
              <div className="flex-1 max-w-md space-y-4">
                <div className="bg-gray-900 rounded-xl border border-gray-800 p-5">
                  <h3 className="text-white font-bold mb-3">✨ What to Try</h3>
                  <ul className="space-y-2 text-sm text-gray-300">
                    {[
                      'Type on QWERTY — tap suggestions bar',
                      'Double-tap Shift for CAPS LOCK',
                      'Switch to 😊 Emoji tab',
                      'HOLD any emoji for rapid-fire spam!',
                      'Switch to 📋 Clipboard tab',
                      'Tap Pin icon to pin clipboard items',
                      'Tap a clipboard item to paste it',
                      'Delete clipboard entries with trash icon',
                    ].map((tip, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-purple-400 font-bold shrink-0">{i + 1}.</span>
                        {tip}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="bg-orange-500/10 border border-orange-500/30 rounded-xl p-4">
                  <p className="text-orange-300 font-semibold text-sm mb-1">🔥 Rapid-Fire Engine</p>
                  <p className="text-orange-200/70 text-xs leading-relaxed">
                    Hold any emoji for 500ms to trigger continuous emission. Rate starts at 9/sec, accelerates to 35+/sec. 
                    Implemented with adaptive coroutine scheduling — zero ANR, zero stuck state.
                  </p>
                </div>
                <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4">
                  <p className="text-blue-300 font-semibold text-sm mb-1">📋 Clipboard Safety</p>
                  <p className="text-blue-200/70 text-xs leading-relaxed">
                    The real Android engine handles 500KB+ text safely using chunk-safe Room storage and lazy reconstruction.
                    Large pastes are committed in 4KB batches with yield() calls to prevent ANR.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ARCHITECTURE */}
        {activeTab === 'architecture' && (
          <div className="max-w-6xl mx-auto px-6 py-12">
            <div className="mb-8">
              <h2 className="text-3xl font-bold text-white mb-2">🏗 System Architecture</h2>
              <p className="text-gray-400">Full layer-by-layer architecture from IME Service to Android Input Framework</p>
            </div>
            <div className="bg-gray-900 rounded-2xl border border-gray-800 p-6 mb-8">
              <ArchDiagram />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {[
                { layer: 'IME Layer', color: '#6366f1', desc: 'InputMethodService with proper LifecycleOwner, ViewModelStoreOwner, and SavedStateRegistryOwner implementation for Compose compatibility' },
                { layer: 'ViewModel Layer', color: '#8b5cf6', desc: 'Single source of truth for all keyboard state exposed as StateFlows. Coordinates all subsystems via structured concurrency' },
                { layer: 'UI Panels (Compose)', color: '#3b82f6', desc: 'QWERTY, Emoji, Clipboard, Settings panels built with Jetpack Compose, LazyVerticalGrid, animated crossfade transitions' },
                { layer: 'Engine Layer', color: '#ef4444', desc: 'LongPressEngine, SuggestionEngine, ClipboardEngine, ThemeEngine — all background-safe, cancellation-aware' },
                { layer: 'Data Layer', color: '#f97316', desc: 'Room DB with WAL mode + auto-migrations for clipboard/emoji/word data. DataStore for typed user preferences' },
                { layer: 'Android Input Framework', color: '#64748b', desc: 'InputConnection.commitText() for text insertion, EditorInfo for context detection, KeyEvent for special keys' },
              ].map(item => (
                <div key={item.layer} className="p-5 bg-gray-900 rounded-xl border border-gray-800">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-3 h-3 rounded-full" style={{ background: item.color }} />
                    <h3 className="text-white font-semibold text-sm">{item.layer}</h3>
                  </div>
                  <p className="text-gray-400 text-xs leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* IME SERVICE */}
        {activeTab === 'ime' && (
          <div className="max-w-6xl mx-auto px-6 py-12 space-y-6">
            <div>
              <h2 className="text-3xl font-bold text-white mb-2">🔌 IME Service Implementation</h2>
              <p className="text-gray-400">Production-grade InputMethodService with full Jetpack Compose lifecycle integration</p>
            </div>
            {CODE_FILE_MAP.ime.map(f => (
              <CodeBlock key={f.name} filename={f.name} description={f.description} code={f.code} language={f.language} defaultExpanded={true} />
            ))}
            {/* Additional context */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
              {[
                { title: 'Why LifecycleOwner in IME?', desc: 'Jetpack Compose requires a LifecycleOwner to manage recomposition. Without it, Compose keeps recomposing after keyboard is dismissed, burning CPU and potentially causing crashes.' },
                { title: 'ViewModelStoreOwner', desc: 'Scopes ViewModels to IME lifecycle. When onDestroy() fires, viewModelStore.clear() is called, releasing all ViewModel resources and cancelling their coroutine scopes.' },
                { title: 'Separate Process', desc: 'android:process=":keyboard" in manifest runs IME in separate process. Crash in host app doesn\'t kill keyboard. IME crash doesn\'t freeze host app.' },
                { title: 'Password Detection', desc: 'EditorInfo.inputType checked on every onStartInputView(). TYPE_TEXT_VARIATION_PASSWORD, WEB_PASSWORD, VISIBLE_PASSWORD all trigger incognito mode.' },
              ].map(item => (
                <div key={item.title} className="p-5 bg-gray-900 rounded-xl border border-gray-800">
                  <h3 className="text-purple-300 font-semibold text-sm mb-2">{item.title}</h3>
                  <p className="text-gray-400 text-xs leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* EMOJI ENGINE */}
        {activeTab === 'emoji' && (
          <div className="max-w-6xl mx-auto px-6 py-12 space-y-6">
            <div>
              <h2 className="text-3xl font-bold text-white mb-2">😂 Emoji System & Long-Press Engine</h2>
              <p className="text-gray-400">Complete emoji system with rapid-fire hold mechanic, adaptive acceleration, and zero ANR risk</p>
            </div>
            <EmojiSpamVisual />
            {CODE_FILE_MAP.emoji.map(f => (
              <CodeBlock key={f.name} filename={f.name} description={f.description} code={f.code} language={f.language} defaultExpanded />
            ))}
            {/* Long press timeline */}
            <div className="bg-gray-900 rounded-2xl border border-gray-800 p-6">
              <h3 className="text-white font-bold mb-4">⏱ Adaptive Acceleration Timeline</h3>
              <div className="space-y-2">
                {[
                  { t: '0ms', event: 'Finger down', desc: 'longPressJob started', active: false },
                  { t: '500ms', event: 'Initial delay expires', desc: '1st emoji emitted @ 110ms interval', active: true },
                  { t: '610ms', event: '2nd emission', desc: 'interval = 99ms (×0.90)', active: true },
                  { t: '709ms', event: '3rd emission', desc: 'interval = 89ms', active: true },
                  { t: '~1.2s', event: 'Interval halved', desc: '~55ms interval, ~18 emojis/sec', active: true },
                  { t: '~2.0s', event: 'Floor reached', desc: '28ms interval — 35 emojis/sec max', active: true },
                  { t: 'Release', event: 'Finger up', desc: 'cancel() → Job.cancel() → INSTANT STOP', active: false },
                ].map(row => (
                  <div key={row.t} className={`flex items-center gap-4 p-3 rounded-lg ${row.active ? 'bg-orange-500/10' : 'bg-gray-800/50'}`}>
                    <span className="font-mono text-xs text-orange-400 w-16 shrink-0">{row.t}</span>
                    <span className="text-white text-sm font-medium w-40 shrink-0">{row.event}</span>
                    <span className="text-gray-400 text-xs">{row.desc}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* CLIPBOARD */}
        {activeTab === 'clipboard' && (
          <div className="max-w-6xl mx-auto px-6 py-12 space-y-6">
            <div>
              <h2 className="text-3xl font-bold text-white mb-2">📋 Advanced Clipboard Engine</h2>
              <p className="text-gray-400">Chunk-safe clipboard manager handling 500KB+ text, 50 history items, with search, pinning, and category detection</p>
            </div>
            {CODE_FILE_MAP.clipboard.map(f => (
              <CodeBlock key={f.name} filename={f.name} description={f.description} code={f.code} language={f.language} defaultExpanded />
            ))}
            {/* Large text safety */}
            <div className="bg-gray-900 rounded-2xl border border-gray-800 p-6">
              <h3 className="text-white font-bold mb-4">📊 Large Text Safety Analysis</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-gray-700">
                      {['Content Type', 'Size', 'Lines', 'Storage', 'Load Time', 'Status'].map(h => (
                        <th key={h} className="text-left pb-3 pr-4 text-gray-400 text-xs font-semibold">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-800">
                    {[
                      { type: 'Tweet', size: '< 1KB', lines: '1-3', storage: 'Inline', load: '< 1ms', ok: true },
                      { type: 'Email body', size: '5KB', lines: '50', storage: 'Inline', load: '< 2ms', ok: true },
                      { type: 'Chat export', size: '100KB', lines: '2000', storage: 'Room TEXT', load: '< 8ms', ok: true },
                      { type: 'JSON response', size: '200KB', lines: '5000', storage: 'Room TEXT', load: '< 15ms', ok: true },
                      { type: 'Code file', size: '400KB', lines: '10000', storage: 'Room TEXT', load: '< 25ms', ok: true },
                      { type: 'Above limit', size: '> 500KB', lines: '12000+', storage: 'Truncated safely', load: '< 30ms', ok: true },
                    ].map(row => (
                      <tr key={row.type} className="hover:bg-gray-800/30">
                        <td className="py-2.5 pr-4 text-gray-200 text-xs">{row.type}</td>
                        <td className="py-2.5 pr-4 text-gray-400 text-xs font-mono">{row.size}</td>
                        <td className="py-2.5 pr-4 text-gray-400 text-xs font-mono">{row.lines}</td>
                        <td className="py-2.5 pr-4 text-gray-400 text-xs">{row.storage}</td>
                        <td className="py-2.5 pr-4 text-gray-400 text-xs font-mono">{row.load}</td>
                        <td className="py-2.5">
                          <span className="text-green-400 text-xs font-medium">✓ Safe</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* PERFORMANCE */}
        {activeTab === 'performance' && (
          <div className="max-w-6xl mx-auto px-6 py-12">
            <div className="mb-8">
              <h2 className="text-3xl font-bold text-white mb-2">⚡ Performance & Optimization</h2>
              <p className="text-gray-400">Comprehensive performance metrics, ANR prevention strategies, and memory optimization</p>
            </div>
            <MetricsPanel />
            <div className="mt-8 space-y-4">
              {allCodeFiles.filter(f => f.name.includes('Performance')).map(f => (
                <CodeBlock key={f.name} filename={f.name} description={f.description} code={f.code} language={f.language} defaultExpanded />
              ))}
            </div>
          </div>
        )}

        {/* THEME */}
        {activeTab === 'theme' && (
          <div className="max-w-6xl mx-auto px-6 py-12 space-y-8">
            <div>
              <h2 className="text-3xl font-bold text-white mb-2">🎨 Theme Engine</h2>
              <p className="text-gray-400">6 built-in themes + Material You + custom colors + AMOLED + glassmorphism</p>
            </div>
            {/* Theme previews */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {[
                { name: 'Default', keys: '#FFFFFF', panel: '#EEEEEE', accent: '#6200EE', text: '#000' },
                { name: 'AMOLED', keys: '#1A1A1A', panel: '#000000', accent: '#00E5FF', text: '#FFF' },
                { name: 'Ocean', keys: '#1565C0', panel: '#0A3069', accent: '#40C4FF', text: '#FFF' },
                { name: 'Forest', keys: '#2E7D32', panel: '#1A3B1C', accent: '#69F0AE', text: '#FFF' },
                { name: 'Candy', keys: '#F8BBD0', panel: '#FCE4EC', accent: '#E91E63', text: '#880E4F' },
                { name: 'Glass', keys: 'rgba(255,255,255,0.2)', panel: 'rgba(0,0,0,0.4)', accent: '#80DEEA', text: '#FFF' },
              ].map(theme => (
                <div key={theme.name}
                  className="rounded-xl overflow-hidden border border-gray-700 shadow-lg"
                  style={{ background: theme.panel }}>
                  <div className="p-3">
                    <div className="flex gap-1 mb-2">
                      {['Q','W','E','R','T'].map(k => (
                        <div key={k}
                          className="flex-1 py-2 rounded-md flex items-center justify-center text-xs font-bold shadow-sm"
                          style={{ background: theme.keys, color: theme.text, fontSize: 11 }}>
                          {k}
                        </div>
                      ))}
                    </div>
                    <div className="flex gap-1">
                      {['A','S','D','F'].map(k => (
                        <div key={k}
                          className="flex-1 py-2 rounded-md flex items-center justify-center text-xs font-bold shadow-sm"
                          style={{ background: theme.keys, color: theme.text, fontSize: 11 }}>
                          {k}
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="px-3 pb-2 text-center">
                    <span className="text-xs font-semibold" style={{ color: theme.accent }}>{theme.name}</span>
                  </div>
                </div>
              ))}
            </div>
            {CODE_FILE_MAP.theme.map(f => (
              <CodeBlock key={f.name} filename={f.name} description={f.description} code={f.code} language={f.language} defaultExpanded />
            ))}
          </div>
        )}

        {/* DATABASE */}
        {activeTab === 'database' && (
          <div className="max-w-6xl mx-auto px-6 py-12 space-y-6">
            <div>
              <h2 className="text-3xl font-bold text-white mb-2">🗄 Database Architecture</h2>
              <p className="text-gray-400">Room database with WAL mode, type-safe DAOs, auto-migrations, and DataStore preferences</p>
            </div>
            {CODE_FILE_MAP.database.map(f => (
              <CodeBlock key={f.name} filename={f.name} description={f.description} code={f.code} language={f.language} defaultExpanded />
            ))}
            {/* DB Schema visual */}
            <div className="bg-gray-900 rounded-2xl border border-gray-800 p-6">
              <h3 className="text-white font-bold mb-4">📐 Database Schema</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { table: 'clipboard', color: '#22c55e', fields: ['id PK', 'preview TEXT', 'fullText TEXT', 'charCount INT', 'lineCount INT', 'category TEXT', 'isPinned BOOL', 'createdAt LONG', 'label TEXT?'], indices: ['createdAt', 'isPinned', 'category'] },
                  { table: 'emoji_history', color: '#f59e0b', fields: ['unicode PK', 'name TEXT', 'category TEXT', 'useCount INT', 'lastUsed LONG', 'isFavorite BOOL'], indices: ['lastUsed'] },
                  { table: 'word_frequency', color: '#3b82f6', fields: ['id PK', 'word TEXT UNIQUE', 'frequency INT', 'lastUsed LONG', 'language TEXT'], indices: ['word'] },
                  { table: 'themes', color: '#a855f7', fields: ['id PK', 'name TEXT', 'configJson TEXT', 'isActive BOOL', 'isPremium BOOL', 'createdAt LONG'], indices: [] },
                ].map(t => (
                  <div key={t.table} className="bg-gray-800/60 rounded-xl border overflow-hidden" style={{ borderColor: t.color + '44' }}>
                    <div className="px-4 py-2 font-mono text-sm font-bold" style={{ background: t.color + '22', color: t.color }}>
                      {t.table}
                    </div>
                    <div className="p-3 space-y-1">
                      {t.fields.map(f => (
                        <div key={f} className="font-mono text-xs text-gray-400 flex items-center gap-1">
                          {f.includes('PK') && <span className="text-yellow-500">🔑</span>}
                          {f.includes('UNIQUE') && <span className="text-orange-500">⚡</span>}
                          {f}
                        </div>
                      ))}
                    </div>
                    {t.indices.length > 0 && (
                      <div className="px-3 pb-2 border-t border-gray-700/50">
                        <p className="text-gray-600 text-xs mt-1">Indexes: {t.indices.join(', ')}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* SECURITY */}
        {activeTab === 'security' && (
          <div className="max-w-6xl mx-auto px-6 py-12 space-y-6">
            <div>
              <h2 className="text-3xl font-bold text-white mb-2">🔐 Security & Privacy</h2>
              <p className="text-gray-400">Password detection, incognito mode, local-only storage, secure clipboard handling</p>
            </div>
            <SecurityPanel />
          </div>
        )}

        {/* BUILD GUIDE */}
        {activeTab === 'build' && (
          <div className="max-w-6xl mx-auto px-6 py-12">
            <div className="mb-8">
              <h2 className="text-3xl font-bold text-white mb-2">🔨 Build Guide & APK Generation</h2>
              <p className="text-gray-400">Complete step-by-step instructions from clone to signed production APK</p>
            </div>
            <BuildGuide />
            {/* Gradle file */}
            <div className="mt-8 space-y-4">
              {allCodeFiles.filter(f => f.name.includes('gradle') || f.name.includes('Manifest')).map(f => (
                <CodeBlock key={f.name} filename={f.name} description={f.description} code={f.code} language={f.language} defaultExpanded />
              ))}
            </div>
          </div>
        )}
      </main>

      {/* ── Footer ──────────────────────────────────────────────────────────── */}
      <footer className="mt-20 border-t border-gray-800 bg-gray-900/50">
        <div className="max-w-6xl mx-auto px-6 py-10">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
                <Keyboard size={16} className="text-white" />
              </div>
              <div>
                <p className="text-white font-bold">NexusKey</p>
                <p className="text-gray-500 text-xs">Production Android Keyboard</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-6 text-sm text-gray-500">
              <span>Kotlin 2.0</span>
              <span>Jetpack Compose</span>
              <span>Room 2.6</span>
              <span>DataStore</span>
              <span>Android 12-15</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="flex items-center gap-1 text-yellow-400 text-sm">
                <Star size={14} fill="currentColor" /> Production Grade
              </span>
              <span className="flex items-center gap-1 text-green-400 text-sm">
                <Package size={14} /> MIT License
              </span>
            </div>
          </div>
          <div className="mt-6 pt-6 border-t border-gray-800/60 text-center text-gray-600 text-xs">
            NexusKey — A complete Android IME implementation with ultra-low latency, rapid-fire emoji, chunk-safe clipboard, and adaptive long-press engine.
            Built with production-grade Kotlin architecture. All source code is complete and functional.
          </div>
        </div>
      </footer>
    </div>
  );
}
