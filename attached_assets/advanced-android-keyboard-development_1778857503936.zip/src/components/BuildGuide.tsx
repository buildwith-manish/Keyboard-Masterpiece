import { useState } from 'react';
import { Terminal, CheckCircle, Copy, Check } from 'lucide-react';

interface Step {
  step: number;
  title: string;
  commands?: string[];
  note?: string;
  badge?: string;
  color: string;
}

const BUILD_STEPS: Step[] = [
  {
    step: 1, title: 'Prerequisites', color: '#6366f1',
    note: 'Install Android Studio Hedgehog (2023.1.1+), JDK 17, Android SDK 35',
    badge: 'Required',
  },
  {
    step: 2, title: 'Clone & Open Project', color: '#3b82f6',
    commands: [
      'git clone https://github.com/nexuskey/android-keyboard',
      'cd android-keyboard',
      'open -a "Android Studio" .',
    ],
  },
  {
    step: 3, title: 'Configure local.properties', color: '#f59e0b',
    commands: ['echo "sdk.dir=/path/to/android-sdk" > local.properties'],
    note: 'On Windows: sdk.dir=C\\:\\\\Users\\\\YourName\\\\AppData\\\\Local\\\\Android\\\\Sdk',
  },
  {
    step: 4, title: 'Sync Gradle & Build', color: '#22c55e',
    commands: [
      './gradlew clean',
      './gradlew assembleDebug',
    ],
    badge: 'Debug APK',
  },
  {
    step: 5, title: 'Install on Device', color: '#06b6d4',
    commands: [
      'adb install app/build/outputs/apk/debug/app-debug.apk',
    ],
    note: 'Enable USB Debugging in Developer Options',
  },
  {
    step: 6, title: 'Enable IME in System Settings', color: '#a855f7',
    note: 'Settings → System → Languages & Input → On-screen keyboard → Manage on-screen keyboards → Enable NexusKey. Then select it as default.',
    badge: 'Manual step',
  },
  {
    step: 7, title: 'Build Release APK', color: '#ef4444',
    commands: [
      '# Create keystore (one-time)',
      'keytool -genkey -v -keystore nexuskey.jks \\',
      '  -alias nexuskey -keyalg RSA -keysize 2048 \\',
      '  -validity 10000',
      '',
      '# Build signed release',
      './gradlew bundleRelease',
      './gradlew assembleRelease',
    ],
    badge: 'Production',
  },
  {
    step: 8, title: 'Run Tests', color: '#f97316',
    commands: [
      './gradlew test                    # Unit tests',
      './gradlew connectedAndroidTest    # Instrumented tests',
      './gradlew :app:composeCompilerMetrics  # Recomposition audit',
    ],
  },
];

const PROJECT_STRUCTURE = `nexus-keyboard/
├── app/
│   ├── src/main/
│   │   ├── AndroidManifest.xml
│   │   ├── kotlin/com/nexuskey/ime/
│   │   │   ├── NexusKeyIMEService.kt      ← IME core
│   │   │   ├── NexusKeyApplication.kt     ← App init
│   │   │   ├── MainActivity.kt            ← Settings launcher
│   │   │   ├── engine/
│   │   │   │   ├── LongPressEngine.kt     ← Emoji spam engine
│   │   │   │   ├── ClipboardEngine.kt     ← Chunk-safe clipboard
│   │   │   │   ├── SuggestionEngine.kt    ← NLP predictions
│   │   │   │   ├── EmojiEngine.kt         ← Emoji data + search
│   │   │   │   └── ThemeEngine.kt         ← Dynamic themes
│   │   │   ├── data/
│   │   │   │   ├── NexusKeyDatabase.kt    ← Room database
│   │   │   │   ├── ClipboardDao.kt        ← Clip queries
│   │   │   │   ├── EmojiDao.kt            ← Emoji history
│   │   │   │   └── WordDao.kt             ← Word frequency
│   │   │   ├── settings/
│   │   │   │   ├── SettingsRepository.kt  ← DataStore wrapper
│   │   │   │   └── KeyboardSettings.kt    ← Settings data class
│   │   │   ├── ui/
│   │   │   │   ├── KeyboardScreen.kt      ← Root Compose UI
│   │   │   │   ├── QwertyPanel.kt         ← QWERTY keyboard
│   │   │   │   ├── EmojiPanel.kt          ← Emoji grid + search
│   │   │   │   ├── ClipboardPanel.kt      ← Clipboard manager
│   │   │   │   ├── SettingsPanel.kt       ← Settings UI
│   │   │   │   ├── components/
│   │   │   │   │   ├── KeyButton.kt       ← Individual key
│   │   │   │   │   ├── SuggestionsBar.kt  ← Word suggestions
│   │   │   │   │   ├── EmojiKey.kt        ← Emoji button + hold
│   │   │   │   │   └── ClipboardCard.kt   ← Clip item card
│   │   │   │   └── theme/
│   │   │   │       ├── NexusKeyTheme.kt   ← Compose theme
│   │   │   │       └── ThemeConfig.kt     ← Theme presets
│   │   │   └── viewmodel/
│   │   │       └── KeyboardViewModel.kt   ← Central ViewModel
│   │   ├── res/
│   │   │   ├── xml/method.xml             ← IME subtypes
│   │   │   └── values/strings.xml
│   │   └── assets/
│   │       └── emoji_data.json            ← Full Unicode emoji DB
│   └── build.gradle.kts
├── gradle/
│   ├── libs.versions.toml                 ← Version catalog
│   └── wrapper/gradle-wrapper.properties
├── build.gradle.kts
└── settings.gradle.kts`;

function CommandLine({ cmd }: { cmd: string; index: number }) {
  const [copied, setCopied] = useState(false);
  if (!cmd || cmd.startsWith('#')) return (
    <div className="font-mono text-xs text-gray-500 italic">{cmd || ' '}</div>
  );
  return (
    <div className="group flex items-center gap-2 hover:bg-gray-700/30 px-2 py-0.5 rounded transition-colors">
      <span className="text-green-400 font-mono text-xs select-none shrink-0">$</span>
      <span className="font-mono text-xs text-gray-200 flex-1">{cmd}</span>
      <button
        onClick={async () => {
          await navigator.clipboard.writeText(cmd);
          setCopied(true);
          setTimeout(() => setCopied(false), 1500);
        }}
        className="opacity-0 group-hover:opacity-100 transition-opacity"
      >
        {copied ? <Check size={11} className="text-green-400" /> : <Copy size={11} className="text-gray-500" />}
      </button>
    </div>
  );
}

export default function BuildGuide() {
  const [activeStep, setActiveStep] = useState<number | null>(null);
  const [copiedStructure, setCopiedStructure] = useState(false);

  return (
    <div className="space-y-8">
      {/* Build Steps */}
      <div>
        <h3 className="text-white font-bold text-lg mb-6 flex items-center gap-2">
          <Terminal size={20} className="text-green-400" />
          Build & Installation Guide
        </h3>
        <div className="space-y-3">
          {BUILD_STEPS.map(step => (
            <div
              key={step.step}
              className="rounded-xl border overflow-hidden cursor-pointer transition-all"
              style={{
                borderColor: activeStep === step.step ? step.color + '60' : '#374151',
                background: activeStep === step.step ? step.color + '0d' : 'transparent',
              }}
              onClick={() => setActiveStep(activeStep === step.step ? null : step.step)}
            >
              <div className="flex items-center gap-4 px-5 py-4">
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold shrink-0"
                  style={{ background: step.color + '33', color: step.color }}
                >
                  {step.step}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-white font-semibold text-sm">{step.title}</span>
                    {step.badge && (
                      <span
                        className="text-xs px-2 py-0.5 rounded-full font-medium"
                        style={{ background: step.color + '33', color: step.color }}
                      >
                        {step.badge}
                      </span>
                    )}
                  </div>
                </div>
                <span className="text-gray-600 text-xs">{activeStep === step.step ? '▲' : '▼'}</span>
              </div>

              {activeStep === step.step && (
                <div className="px-5 pb-4 border-t border-gray-700/40">
                  {step.note && (
                    <p className="text-gray-400 text-sm my-3 leading-relaxed">{step.note}</p>
                  )}
                  {step.commands && (
                    <div className="bg-gray-950 rounded-lg p-3 mt-2 border border-gray-800">
                      {step.commands.map((cmd, i) => (
                        <CommandLine key={i} cmd={cmd} index={i} />
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Project Structure */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-white font-bold text-lg">📁 Project Structure</h3>
          <button
            onClick={async () => {
              await navigator.clipboard.writeText(PROJECT_STRUCTURE);
              setCopiedStructure(true);
              setTimeout(() => setCopiedStructure(false), 2000);
            }}
            className="flex items-center gap-1 text-xs text-gray-400 hover:text-gray-200 transition-colors bg-gray-800 px-3 py-1.5 rounded-lg"
          >
            {copiedStructure ? <Check size={12} className="text-green-400" /> : <Copy size={12} />}
            Copy
          </button>
        </div>
        <div className="bg-gray-950 rounded-xl p-4 border border-gray-800 overflow-x-auto">
          <pre className="font-mono text-xs text-gray-300 leading-relaxed whitespace-pre">{PROJECT_STRUCTURE}</pre>
        </div>
      </div>

      {/* Checklist */}
      <div>
        <h3 className="text-white font-bold text-lg mb-4">✅ Production Readiness Checklist</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {[
            'IME lifecycle fully managed (no leaks)',
            'Compose tree owners wired correctly',
            'Long-press engine uses structured concurrency',
            'Clipboard handles 500KB+ without OOM',
            'All DB ops on Dispatchers.IO',
            'SupervisorJob prevents cascade failures',
            'Password field detection implemented',
            'onTrimMemory() clears caches',
            'No static Context references',
            'Room WAL mode enabled',
            'DataStore replaces SharedPreferences',
            'Proguard rules for Room/Compose',
            'Baseline Profiles for cold start',
            'Recomposition audit with compiler metrics',
            'Unit tests for LongPressEngine',
            'Instrumented tests for ClipboardEngine',
            'Android 12-15 compatibility verified',
            'RTL layout support',
            'Accessibility (TalkBack) compatible',
            'Low-RAM device tested (2GB)',
          ].map(item => (
            <div key={item} className="flex items-center gap-2 p-2.5 bg-gray-800/40 rounded-lg">
              <CheckCircle size={14} className="text-green-400 shrink-0" />
              <span className="text-gray-300 text-xs">{item}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
