import React, { useState } from 'react';
import { Check, Copy, ChevronDown, ChevronUp } from 'lucide-react';

interface CodeBlockProps {
  code: string;
  language?: string;
  filename?: string;
  description?: string;
  defaultExpanded?: boolean;
}

// Simple syntax highlighter using regex-based tokenization
function tokenize(code: string, language: string): React.ReactNode[] {
  if (language === 'markdown') {
    return code.split('\n').map((line, i) => {
      let className = 'text-gray-300';
      if (line.startsWith('# ')) className = 'text-purple-300 font-bold text-lg';
      else if (line.startsWith('## ')) className = 'text-blue-300 font-bold';
      else if (line.startsWith('### ')) className = 'text-cyan-300 font-semibold';
      else if (line.startsWith('- ') || line.startsWith('* ')) className = 'text-green-300';
      else if (line.startsWith('|')) className = 'text-yellow-200 font-mono text-xs';
      else if (line.startsWith('```')) className = 'text-gray-500';
      else if (/^\d+\./.test(line)) className = 'text-orange-300';
      return <div key={i} className={className}>{line || '\u00A0'}</div>;
    });
  }

  const lines = code.split('\n');
  return lines.map((line, lineIdx) => {
    // Comment line
    if (line.trim().startsWith('//') || line.trim().startsWith('*') || line.trim().startsWith('/*') || line.trim().startsWith('<!--')) {
      return <div key={lineIdx} className="text-gray-500 italic">{line || '\u00A0'}</div>;
    }

    // XML/manifest
    if (language === 'xml') {
      return (
        <div key={lineIdx}>
          {line.split(/(<[^>]+>)/).map((part, i) =>
            part.startsWith('<') ? (
              <span key={i} className="text-blue-400">{part}</span>
            ) : part.includes('=') ? (
              <span key={i} className="text-yellow-300">{part}</span>
            ) : (
              <span key={i} className="text-gray-300">{part}</span>
            )
          )}
          {!line && '\u00A0'}
        </div>
      );
    }

    // Kotlin/Gradle tokenization
    const patterns: Array<{ re: RegExp; cls: string }> = [
      { re: /\b(class|object|interface|fun|val|var|override|private|public|protected|internal|suspend|inline|companion|data|sealed|abstract|open|final|lazy|by|get|set|return|if|else|when|for|while|do|in|is|as|null|true|false|this|super|import|package|enum|init)\b/, cls: 'text-purple-400' },
      { re: /\b(String|Int|Long|Boolean|Float|Double|Unit|Any|List|Map|Set|Flow|StateFlow|MutableStateFlow|Job|CoroutineScope|Context|View|Color|Modifier)\b/, cls: 'text-cyan-300' },
      { re: /"[^"]*"/, cls: 'text-green-400' },
      { re: /\b\d+[Lf]?\b/, cls: 'text-orange-400' },
      { re: /@\w+/, cls: 'text-yellow-400' },
      { re: /\b[A-Z][A-Z_0-9]+\b/, cls: 'text-orange-300' },
      { re: /\b[A-Z]\w+(?=\s*[({<])/, cls: 'text-blue-300' },
    ];

    // Simple pass — just color known keywords
    const remaining = line;
    let segKey = 0;
    const segments: React.ReactNode[] = [];

    // Split by known keyword patterns
    const allPattern = new RegExp(patterns.map(p => `(${p.re.source})`).join('|'), 'g');
    let lastIndex = 0;
    let match: RegExpExecArray | null;

    allPattern.lastIndex = 0;
    while ((match = allPattern.exec(remaining)) !== null) {
      if (match.index > lastIndex) {
        segments.push(<span key={segKey++} className="text-gray-300">{remaining.slice(lastIndex, match.index)}</span>);
      }
      const matchedText = match[0];
      let cls = 'text-gray-300';
      for (const pat of patterns) {
        if (pat.re.test(matchedText)) { cls = pat.cls; break; }
      }
      segments.push(<span key={segKey++} className={cls}>{matchedText}</span>);
      lastIndex = match.index + matchedText.length;
    }
    if (lastIndex < remaining.length) {
      segments.push(<span key={segKey++} className="text-gray-300">{remaining.slice(lastIndex)}</span>);
    }

    return <div key={lineIdx}>{segments.length > 0 ? segments : <span className="text-gray-300">{line}</span>}{!line && '\u00A0'}</div>;
  });
}

export default function CodeBlock({ code, language = 'kotlin', filename, description, defaultExpanded = false }: CodeBlockProps) {
  const [copied, setCopied] = useState(false);
  const [expanded, setExpanded] = useState(defaultExpanded);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const lineCount = code.split('\n').length;

  return (
    <div className="rounded-xl overflow-hidden border border-gray-700/50 bg-gray-950 shadow-xl">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-gray-900/80 border-b border-gray-700/50">
        <div className="flex items-center gap-3">
          <div className="flex gap-1.5">
            <div className="w-3 h-3 rounded-full bg-red-500/80" />
            <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
            <div className="w-3 h-3 rounded-full bg-green-500/80" />
          </div>
          <div className="flex flex-col">
            <span className="text-gray-200 text-sm font-semibold font-mono">{filename}</span>
            {description && <span className="text-gray-500 text-xs">{description}</span>}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-gray-600 text-xs">{lineCount} lines</span>
          <button
            onClick={handleCopy}
            className="flex items-center gap-1 px-2 py-1 rounded-md bg-gray-800 hover:bg-gray-700 text-gray-400 hover:text-gray-200 transition-colors text-xs"
          >
            {copied ? <Check size={12} className="text-green-400" /> : <Copy size={12} />}
            {copied ? 'Copied' : 'Copy'}
          </button>
          <button
            onClick={() => setExpanded(!expanded)}
            className="flex items-center gap-1 px-2 py-1 rounded-md bg-gray-800 hover:bg-gray-700 text-gray-400 hover:text-gray-200 transition-colors text-xs"
          >
            {expanded ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
            {expanded ? 'Collapse' : 'Expand'}
          </button>
        </div>
      </div>

      {/* Code content */}
      {expanded && (
        <div className="overflow-auto max-h-[600px]">
          <div className="p-4 font-mono text-xs leading-relaxed">
            <div className="flex gap-4">
              {/* Line numbers */}
              <div className="select-none text-gray-700 text-right min-w-[2rem] shrink-0">
                {code.split('\n').map((_, i) => (
                  <div key={i}>{i + 1}</div>
                ))}
              </div>
              {/* Code */}
              <div className="flex-1 overflow-x-auto">
                <pre className="whitespace-pre">
                  {tokenize(code, language)}
                </pre>
              </div>
            </div>
          </div>
        </div>
      )}

      {!expanded && (
        <div
          className="p-4 font-mono text-xs text-gray-500 cursor-pointer hover:bg-gray-900/50 transition-colors"
          onClick={() => setExpanded(true)}
        >
          <span className="text-gray-600">// Click to expand • {lineCount} lines of production Kotlin</span>
        </div>
      )}
    </div>
  );
}
