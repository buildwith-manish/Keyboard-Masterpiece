import { useState } from 'react';

interface Node {
  id: string;
  label: string;
  sublabel?: string;
  color: string;
  x: number;
  y: number;
  w: number;
  h: number;
}

interface Edge {
  from: string;
  to: string;
  label?: string;
  color?: string;
}

const NODES: Node[] = [
  // IME Core
  { id: 'ime', label: 'NexusKeyIMEService', sublabel: 'InputMethodService', color: '#6366f1', x: 300, y: 30, w: 200, h: 56 },
  // ViewModels
  { id: 'vm', label: 'KeyboardViewModel', sublabel: 'StateFlow sources', color: '#8b5cf6', x: 300, y: 140, w: 200, h: 56 },
  // UI Panels
  { id: 'qwerty', label: 'QwertyPanel', sublabel: 'Compose UI', color: '#3b82f6', x: 60, y: 260, w: 140, h: 48 },
  { id: 'emoji', label: 'EmojiPanel', sublabel: 'LazyVerticalGrid', color: '#f59e0b', x: 230, y: 260, w: 140, h: 48 },
  { id: 'clip', label: 'ClipboardPanel', sublabel: 'LazyColumn', color: '#10b981', x: 400, y: 260, w: 140, h: 48 },
  { id: 'settings', label: 'SettingsPanel', sublabel: 'Compose UI', color: '#f43f5e', x: 570, y: 260, w: 130, h: 48 },
  // Engines
  { id: 'lp', label: 'LongPressEngine', sublabel: 'Adaptive repeat', color: '#ef4444', x: 60, y: 380, w: 160, h: 48 },
  { id: 'suggest', label: 'SuggestionEngine', sublabel: 'NLP + WordFreq', color: '#06b6d4', x: 250, y: 380, w: 160, h: 48 },
  { id: 'clipeng', label: 'ClipboardEngine', sublabel: 'Chunk-safe', color: '#22c55e', x: 440, y: 380, w: 160, h: 48 },
  { id: 'themeeng', label: 'ThemeEngine', sublabel: 'Dynamic themes', color: '#a855f7', x: 620, y: 380, w: 140, h: 48 },
  // Data
  { id: 'room', label: 'Room Database', sublabel: 'WAL + AutoMigrate', color: '#f97316', x: 180, y: 490, w: 160, h: 48 },
  { id: 'datastore', label: 'DataStore', sublabel: 'Typed preferences', color: '#0ea5e9', x: 380, y: 490, w: 160, h: 48 },
  // Input
  { id: 'ic', label: 'InputConnection', sublabel: 'commitText()', color: '#64748b', x: 300, y: 590, w: 180, h: 48 },
];

const EDGES: Edge[] = [
  { from: 'ime', to: 'vm', label: 'owns', color: '#a5b4fc' },
  { from: 'vm', to: 'qwerty', label: 'state', color: '#93c5fd' },
  { from: 'vm', to: 'emoji', label: 'state', color: '#fcd34d' },
  { from: 'vm', to: 'clip', label: 'state', color: '#6ee7b7' },
  { from: 'vm', to: 'settings', label: 'state', color: '#fda4af' },
  { from: 'vm', to: 'lp', label: 'delegates', color: '#fca5a5' },
  { from: 'vm', to: 'suggest', label: 'delegates', color: '#67e8f9' },
  { from: 'vm', to: 'clipeng', label: 'delegates', color: '#86efac' },
  { from: 'vm', to: 'themeeng', label: 'delegates', color: '#d8b4fe' },
  { from: 'clipeng', to: 'room', color: '#fb923c' },
  { from: 'suggest', to: 'room', color: '#fb923c' },
  { from: 'themeeng', to: 'datastore', color: '#38bdf8' },
  { from: 'room', to: 'ic', label: 'via commitText', color: '#94a3b8' },
  { from: 'qwerty', to: 'ic', color: '#94a3b8' },
  { from: 'emoji', to: 'ic', color: '#94a3b8' },
  { from: 'clip', to: 'ic', color: '#94a3b8' },
];

function getCenter(node: Node) {
  return { x: node.x + node.w / 2, y: node.y + node.h / 2 };
}

export default function ArchDiagram() {
  const [hovered, setHovered] = useState<string | null>(null);

  const nodeMap = Object.fromEntries(NODES.map(n => [n.id, n]));

  return (
    <div className="w-full overflow-x-auto">
      <svg viewBox="0 0 780 660" className="w-full" style={{ minWidth: 600 }}>
        <defs>
          <marker id="arrowhead" markerWidth="8" markerHeight="6" refX="8" refY="3" orient="auto">
            <polygon points="0 0, 8 3, 0 6" fill="#475569" />
          </marker>
          {NODES.map(n => (
            <filter key={n.id} id={`glow-${n.id}`}>
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          ))}
        </defs>

        {/* Edges */}
        {EDGES.map((edge, i) => {
          const from = nodeMap[edge.from];
          const to = nodeMap[edge.to];
          if (!from || !to) return null;
          const fc = getCenter(from);
          const tc = getCenter(to);
          const isHighlighted = hovered === edge.from || hovered === edge.to;
          return (
            <g key={i}>
              <line
                x1={fc.x} y1={fc.y + from.h / 2}
                x2={tc.x} y2={tc.y - to.h / 2}
                stroke={isHighlighted ? (edge.color || '#64748b') : '#334155'}
                strokeWidth={isHighlighted ? 2 : 1}
                strokeDasharray={isHighlighted ? undefined : '4 3'}
                markerEnd="url(#arrowhead)"
                opacity={isHighlighted ? 1 : 0.5}
              />
              {edge.label && isHighlighted && (
                <text
                  x={(fc.x + tc.x) / 2 + 6}
                  y={(fc.y + from.h / 2 + tc.y - to.h / 2) / 2}
                  fill={edge.color || '#94a3b8'}
                  fontSize="9"
                  fontFamily="JetBrains Mono, monospace"
                >
                  {edge.label}
                </text>
              )}
            </g>
          );
        })}

        {/* Nodes */}
        {NODES.map(node => {
          const isHov = hovered === node.id;
          return (
            <g
              key={node.id}
              onMouseEnter={() => setHovered(node.id)}
              onMouseLeave={() => setHovered(null)}
              style={{ cursor: 'pointer' }}
            >
              <rect
                x={node.x}
                y={node.y}
                width={node.w}
                height={node.h}
                rx={8}
                fill={node.color + (isHov ? 'ff' : '33')}
                stroke={node.color}
                strokeWidth={isHov ? 2 : 1}
                opacity={isHov ? 1 : 0.9}
              />
              <text
                x={node.x + node.w / 2}
                y={node.y + (node.sublabel ? 20 : node.h / 2 + 5)}
                textAnchor="middle"
                fill={isHov ? '#fff' : '#e2e8f0'}
                fontSize="11"
                fontWeight="600"
                fontFamily="Inter, sans-serif"
              >
                {node.label}
              </text>
              {node.sublabel && (
                <text
                  x={node.x + node.w / 2}
                  y={node.y + 35}
                  textAnchor="middle"
                  fill={isHov ? node.color + 'dd' : '#64748b'}
                  fontSize="9"
                  fontFamily="JetBrains Mono, monospace"
                >
                  {node.sublabel}
                </text>
              )}
            </g>
          );
        })}

        {/* Layer labels */}
        {[
          { y: 14, label: 'IME LAYER', color: '#6366f1' },
          { y: 124, label: 'VIEWMODEL LAYER', color: '#8b5cf6' },
          { y: 244, label: 'UI PANELS (Compose)', color: '#3b82f6' },
          { y: 364, label: 'ENGINE LAYER', color: '#ef4444' },
          { y: 474, label: 'DATA LAYER', color: '#f97316' },
          { y: 574, label: 'ANDROID INPUT FRAMEWORK', color: '#64748b' },
        ].map(({ y, label, color }) => (
          <text key={label} x={10} y={y} fill={color} fontSize="8" fontWeight="700" fontFamily="JetBrains Mono, monospace" opacity={0.7}>
            {label}
          </text>
        ))}
      </svg>
      <p className="text-center text-gray-600 text-xs mt-2">Hover a node to highlight connections</p>
    </div>
  );
}
