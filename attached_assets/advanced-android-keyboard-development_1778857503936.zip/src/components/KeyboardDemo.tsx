import { useState, useRef, useCallback, useEffect } from 'react';
import { Delete, CornerDownLeft, Smile, Clipboard, Settings, Search, Pin, Trash2, X } from 'lucide-react';

const QWERTY_ROWS = [
  ['q','w','e','r','t','y','u','i','o','p'],
  ['a','s','d','f','g','h','j','k','l'],
  ['z','x','c','v','b','n','m'],
];

const EMOJI_CATEGORIES = [
  { id: 'recent', label: '🕐', name: 'Recent' },
  { id: 'faces', label: '😀', name: 'Faces' },
  { id: 'nature', label: '🌿', name: 'Nature' },
  { id: 'food', label: '🍕', name: 'Food' },
  { id: 'activity', label: '⚽', name: 'Activity' },
  { id: 'travel', label: '✈️', name: 'Travel' },
  { id: 'objects', label: '💡', name: 'Objects' },
  { id: 'symbols', label: '❤️', name: 'Symbols' },
];

const EMOJIS: Record<string, string[]> = {
  recent: ['😂','❤️','🔥','✅','👍','😊','🎉','💯','🙏','😍','🤣','😭','😎','🥳','💪'],
  faces: ['😀','😁','😂','🤣','😃','😄','😅','😆','😉','😊','😋','😎','😍','🥰','😘','😗','😙','😚','🙂','🤗','🤩','🤔','🤨','😐','😑','😶','🙄','😏','😣','😥','😮','🤐','😯','😪','😫','🥱','😴','😌','😛','😜','😝','🤤','😒','😓','😔','😕','🙃','🤑','😲','☹️','🙁','😖','😞','😟','😤','😢','😭','😦','😧','😨','😩','🤯','😬','😰','😱','🥵','🥶','😳','🤪','😵','🥴','😠','😡','🤬','😷','🤒','🤕','🤢','🤮','🤧','😇','🥳','🥸','🤠','🥺','🫠','🤡','🤥'],
  nature: ['🌸','🌺','🌻','🌹','🌷','🌼','💐','🍀','🌿','🪴','🌱','🌲','🌳','🌴','🍃','🍂','🍁','🍄','🌾','🌵','🎋','🎍','🪨','🌊','🌬','🌀','🌈','⚡','❄️','🔥','💧','🌙','⭐','🌟','💫','✨','☀️','🌤️','⛅','🌦️','🌧️','🌨️','🌩️','🌪️','🌫️','🦋','🐝','🐞','🦗','🦟','🐛','🐌','🐜'],
  food: ['🍕','🍔','🌮','🌯','🥪','🥗','🍜','🍝','🍛','🍣','🍱','🍤','🥘','🍲','🫕','🥫','🍿','🧂','🥓','🥩','🍗','🍖','🌭','🥞','🧇','🧆','🥚','🍳','🥐','🥖','🍞','🥨','🥯','🧁','🎂','🍰','🍩','🍪','🍫','🍬','🍭','🍮','🍦','🍧','🍨','🍡','🍢','🍣','🍤','🍥','🥮','🍙','🍚','🍘'],
  activity: ['⚽','🏀','🏈','⚾','🥎','🏐','🏉','🎾','🥏','🎳','🏏','🏑','🏒','🥍','🏓','🏸','🥊','🥋','🎽','🛹','🛷','⛸️','🥌','🎿','⛷️','🏂','🪂','🏋️','🤼','🤸','⛹️','🤺','🏇','🧘','🏄','🏊','🤽','🚣','🧗','🚵','🚴','🏆','🥇','🥈','🥉','🏅','🎖️','🎗️','🎫','🎟️','🎪'],
  travel: ['✈️','🚀','🛸','🚁','🛺','🚂','🚃','🚄','🚅','🚆','🚇','🚈','🚉','🚊','🚝','🚞','🚋','🚌','🚍','🚎','🏎️','🚐','🚑','🚒','🚓','🚔','🚕','🚖','🚗','🚘','🚙','🛻','🚚','🚛','🚜','🏍️','🛵','🦽','🦼','🛴','🚲','🛖','🏠','🏡','🏢','🏣','🏤','🏥','🏦','🏨','🏩','🏪','🏫','🏬','🏭','🗼','🗽','🗾'],
  objects: ['💡','🔦','🕯️','🪔','🔋','🪫','💻','⌨️','🖥️','🖨️','📱','☎️','📞','📟','📠','📺','📻','🎙️','📷','📸','📹','🎥','📽️','🎞️','📞','📮','📭','📬','📫','📪','📦','📫','🔑','🗝️','🔐','🔏','🔓','🔒','🔨','⚒️','🛠️','⛏️','⚙️','🗜️','⚖️','🦯','🔗','⛓️','🧲','🔮','🪄','🧿','🪬'],
  symbols: ['❤️','🧡','💛','💚','💙','💜','🖤','🤍','🤎','❤️‍🔥','❤️‍🩹','💔','❣️','💕','💞','💓','💗','💖','💘','💝','💟','☮️','✝️','☪️','🕉️','✡️','🔯','🕎','☯️','☦️','🛐','⛎','♈','♉','♊','♋','♌','♍','♎','♏','♐','♑','♒','♓','🆔','⚛️','🉑','☢️','☣️','📴','📳','🈶','🈚','🈸','🈺','🈷️','✴️'],
};

const CLIPBOARD_ITEMS = [
  { id: 1, preview: 'Meeting at 3pm tomorrow — bring the Q3 report and slides', chars: 57, pinned: true, category: 'TEXT', time: '2m ago' },
  { id: 2, preview: '{"status":"success","data":{"userId":12345,"token":"eyJ...', chars: 1284, pinned: false, category: 'JSON', time: '15m ago' },
  { id: 3, preview: 'https://github.com/nexuskey/android-keyboard/releases/v1.0', chars: 59, pinned: true, category: 'URL', time: '1h ago' },
  { id: 4, preview: 'fun commitText(text: String) {\n  currentInputConnection?.commitText(text, 1)\n}', chars: 78, pinned: false, category: 'CODE', time: '2h ago' },
  { id: 5, preview: 'John Smith\njohn.smith@company.com\n+1 (555) 123-4567', chars: 50, pinned: false, category: 'TEXT', time: '3h ago' },
];

const CATEGORY_COLORS: Record<string, string> = {
  TEXT: 'bg-blue-500/20 text-blue-300',
  JSON: 'bg-yellow-500/20 text-yellow-300',
  URL: 'bg-green-500/20 text-green-300',
  CODE: 'bg-purple-500/20 text-purple-300',
  EMAIL: 'bg-orange-500/20 text-orange-300',
};

type Panel = 'qwerty' | 'emoji' | 'clipboard';

export default function KeyboardDemo() {
  const [text, setText] = useState('');
  const [panel, setPanel] = useState<Panel>('qwerty');
  const [shifted, setShifted] = useState(false);
  const [shiftLocked, setShiftLocked] = useState(false);
  const [emojiCat, setEmojiCat] = useState('recent');
  const [emojiSearch, setEmojiSearch] = useState('');
  const [spamActive, setSpamActive] = useState(false);
  const [spamEmoji, setSpamEmoji] = useState('');
  const [spamCount, setSpamCount] = useState(0);
  const [recentEmojis, setRecentEmojis] = useState<string[]>(EMOJIS.recent.slice(0, 15));
  const [clipPinned, setClipPinned] = useState<Set<number>>(new Set([1, 3]));
  const [clipItems, setClipItems] = useState(CLIPBOARD_ITEMS);
  const longPressRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const repeatRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const intervalRef = useRef(110);

  const clearTimers = useCallback(() => {
    if (longPressRef.current) clearTimeout(longPressRef.current);
    if (repeatRef.current) clearInterval(repeatRef.current);
    longPressRef.current = null;
    repeatRef.current = null;
    intervalRef.current = 110;
    setSpamActive(false);
    setSpamEmoji('');
  }, []);

  useEffect(() => clearTimers, [clearTimers]);

  const commitText = useCallback((t: string) => {
    setText(prev => prev + t);
  }, []);

  const handleKey = useCallback((char: string) => {
    const out = (shifted || shiftLocked) ? char.toUpperCase() : char;
    commitText(out);
    if (shifted && !shiftLocked) setShifted(false);
  }, [shifted, shiftLocked, commitText]);

  const handleShift = () => {
    if (shiftLocked) { setShiftLocked(false); setShifted(false); return; }
    if (shifted) { setShiftLocked(true); return; }
    setShifted(true);
  };

  const handleDelete = useCallback(() => {
    setText(prev => prev.slice(0, -1));
  }, []);

  const handleEmojiTap = useCallback((emoji: string) => {
    commitText(emoji);
    setRecentEmojis(prev => {
      const next = [emoji, ...prev.filter(e => e !== emoji)].slice(0, 15);
      return next;
    });
  }, [commitText]);

  const startEmojiSpam = useCallback((emoji: string) => {
    clearTimers();
    longPressRef.current = setTimeout(() => {
      setSpamActive(true);
      setSpamEmoji(emoji);
      setSpamCount(0);
      commitText(emoji);
      setSpamCount(1);

      intervalRef.current = 110;
      const tick = () => {
        commitText(emoji);
        setSpamCount(c => c + 1);
        intervalRef.current = Math.max(28, Math.floor(intervalRef.current * 0.90));
        repeatRef.current = setTimeout(tick, intervalRef.current);
      };
      repeatRef.current = setTimeout(tick, 110);
    }, 500);
  }, [clearTimers, commitText]);

  const stopEmojiSpam = useCallback(() => {
    clearTimers();
  }, [clearTimers]);

  const handleClipPaste = (preview: string) => {
    commitText(preview + ' ');
    setPanel('qwerty');
  };

  const togglePin = (id: number) => {
    setClipPinned(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const deleteClip = (id: number) => {
    setClipItems(prev => prev.filter(i => i.id !== id));
  };

  const filteredEmojis = emojiSearch
    ? Object.values(EMOJIS).flat().filter(e => e.includes(emojiSearch)).slice(0, 40)
    : (emojiCat === 'recent' ? recentEmojis : EMOJIS[emojiCat] || []);

  return (
    <div className="flex flex-col items-center gap-4">
      {/* Phone frame */}
      <div className="relative bg-gray-900 rounded-[2.5rem] border-4 border-gray-700 shadow-2xl overflow-hidden"
           style={{ width: 360, minHeight: 620 }}>
        {/* Status bar */}
        <div className="flex items-center justify-between px-6 py-2 bg-gray-950">
          <span className="text-white text-xs font-medium">9:41</span>
          <div className="flex gap-1 items-center">
            <div className="w-3 h-2 border border-white/60 rounded-sm"><div className="h-full w-2/3 bg-green-400 rounded-sm" /></div>
            <span className="text-white text-xs">📶</span>
          </div>
        </div>

        {/* App bar */}
        <div className="bg-blue-600 px-4 py-3">
          <p className="text-white font-semibold text-sm">Messages — Test Input Field</p>
        </div>

        {/* Text area */}
        <div className="bg-gray-800 mx-3 mt-3 rounded-xl p-3 min-h-[120px] max-h-[160px] overflow-y-auto">
          <p className="text-gray-300 text-sm leading-relaxed break-all">
            {text || <span className="text-gray-600">Type something...</span>}
            <span className="inline-block w-0.5 h-4 bg-blue-400 ml-0.5 animate-pulse" />
          </p>
        </div>

        {/* Spam indicator */}
        {spamActive && (
          <div className="mx-3 mt-1 flex items-center gap-2 bg-orange-500/20 border border-orange-500/40 rounded-lg px-3 py-1.5">
            <div className="w-2 h-2 bg-orange-400 rounded-full animate-pulse" />
            <span className="text-orange-300 text-xs font-medium">
              Rapid Fire: {spamEmoji} × {spamCount} — hold to continue!
            </span>
          </div>
        )}

        {/* ── KEYBOARD PANEL ── */}
        <div className="mt-2 bg-gray-850" style={{ background: '#1a1f2e' }}>
          {/* Suggestions bar */}
          {panel === 'qwerty' && (
            <div className="flex border-b border-gray-700/50">
              {['the', 'and', 'you', 'that', 'was'].map(s => (
                <button key={s} onClick={() => commitText(s + ' ')}
                  className="flex-1 py-2 text-gray-300 text-xs hover:bg-gray-700/40 transition-colors border-r border-gray-700/30 last:border-r-0">
                  {s}
                </button>
              ))}
            </div>
          )}

          {/* Panel content */}
          {panel === 'qwerty' && (
            <div className="px-1 py-2 space-y-1">
              {QWERTY_ROWS.map((row, ri) => (
                <div key={ri} className="flex justify-center gap-1">
                  {ri === 2 && (
                    <button onClick={handleShift}
                      className={`px-3 py-3 rounded-lg text-xs font-bold min-w-[42px] transition-all active:scale-95 ${
                        shiftLocked ? 'bg-blue-500 text-white' : shifted ? 'bg-blue-400/60 text-white' : 'bg-gray-600 text-gray-200'
                      }`}>
                      ⬆
                    </button>
                  )}
                  {row.map(c => (
                    <button key={c} onClick={() => handleKey(c)}
                      className="flex-1 max-w-[36px] py-3 bg-gray-700 hover:bg-gray-600 active:bg-gray-500 active:scale-95 text-white rounded-lg text-sm font-medium transition-all shadow-sm select-none">
                      {(shifted || shiftLocked) ? c.toUpperCase() : c}
                    </button>
                  ))}
                  {ri === 2 && (
                    <button onClick={handleDelete}
                      className="px-3 py-3 rounded-lg bg-gray-600 text-gray-200 text-xs min-w-[42px] active:scale-95 transition-all hover:bg-gray-500">
                      <Delete size={14} className="mx-auto" />
                    </button>
                  )}
                </div>
              ))}
              {/* Space row */}
              <div className="flex gap-1 px-1">
                <button onClick={() => setPanel('emoji')}
                  className="px-3 py-3 rounded-lg bg-gray-600 text-gray-300 text-xs active:scale-95 transition-all min-w-[40px] hover:bg-gray-500">
                  <Smile size={14} className="mx-auto" />
                </button>
                <button onClick={() => commitText(',')}
                  className="px-2 py-3 rounded-lg bg-gray-700 text-gray-300 text-xs active:scale-95 transition-all hover:bg-gray-600">,</button>
                <button onClick={() => commitText(' ')}
                  className="flex-1 py-3 rounded-lg bg-gray-700 text-gray-500 text-xs active:scale-95 transition-all hover:bg-gray-600">
                  SPACE
                </button>
                <button onClick={() => commitText('.')}
                  className="px-2 py-3 rounded-lg bg-gray-700 text-gray-300 text-xs active:scale-95 transition-all hover:bg-gray-600">.</button>
                <button onClick={() => commitText('\n')}
                  className="px-3 py-3 rounded-lg bg-blue-600 text-white text-xs active:scale-95 transition-all min-w-[40px] hover:bg-blue-500">
                  <CornerDownLeft size={14} className="mx-auto" />
                </button>
              </div>
            </div>
          )}

          {/* Emoji panel */}
          {panel === 'emoji' && (
            <div>
              {/* Search */}
              <div className="flex items-center gap-2 px-3 py-2 border-b border-gray-700/50">
                <Search size={14} className="text-gray-500" />
                <input
                  className="flex-1 bg-transparent text-gray-300 text-xs outline-none placeholder-gray-600"
                  placeholder="Search emoji..."
                  value={emojiSearch}
                  onChange={e => setEmojiSearch(e.target.value)}
                />
                {emojiSearch && <button onClick={() => setEmojiSearch('')}><X size={12} className="text-gray-500" /></button>}
              </div>

              {/* Category tabs */}
              {!emojiSearch && (
                <div className="flex overflow-x-auto border-b border-gray-700/50 scrollbar-hide">
                  {EMOJI_CATEGORIES.map(cat => (
                    <button key={cat.id} onClick={() => setEmojiCat(cat.id)}
                      className={`shrink-0 px-3 py-2 text-lg transition-colors ${
                        emojiCat === cat.id ? 'border-b-2 border-blue-400 bg-gray-700/40' : 'text-gray-400 hover:bg-gray-700/20'
                      }`}>
                      {cat.label}
                    </button>
                  ))}
                </div>
              )}

              {/* Emoji grid */}
              <div className="grid overflow-y-auto" style={{ gridTemplateColumns: 'repeat(8, 1fr)', maxHeight: 180 }}>
                {filteredEmojis.map((emoji, i) => (
                  <button
                    key={`${emoji}-${i}`}
                    onClick={() => handleEmojiTap(emoji)}
                    onMouseDown={() => startEmojiSpam(emoji)}
                    onMouseUp={stopEmojiSpam}
                    onMouseLeave={stopEmojiSpam}
                    onTouchStart={() => startEmojiSpam(emoji)}
                    onTouchEnd={stopEmojiSpam}
                    className="text-2xl py-2 hover:bg-gray-700/50 active:bg-gray-600/70 active:scale-110 transition-all rounded select-none"
                  >
                    {emoji}
                  </button>
                ))}
              </div>

              {/* Hint */}
              <div className="text-center py-1 border-t border-gray-700/50">
                <span className="text-gray-600 text-xs">Hold emoji for rapid-fire 🔥</span>
              </div>
            </div>
          )}

          {/* Clipboard panel */}
          {panel === 'clipboard' && (
            <div className="overflow-y-auto" style={{ maxHeight: 260 }}>
              <div className="px-3 py-2 border-b border-gray-700/50 flex items-center justify-between">
                <span className="text-gray-400 text-xs font-medium">Clipboard History</span>
                <span className="text-gray-600 text-xs">{clipItems.length} items</span>
              </div>
              <div className="divide-y divide-gray-700/30">
                {clipItems
                  .sort((a, b) => (clipPinned.has(b.id) ? 1 : 0) - (clipPinned.has(a.id) ? 1 : 0))
                  .map(item => (
                  <div key={item.id} className="px-3 py-2.5 hover:bg-gray-700/30 transition-colors">
                    <div className="flex items-start gap-2">
                      <div className="flex-1 min-w-0">
                        <button onClick={() => handleClipPaste(item.preview)} className="w-full text-left">
                          <p className="text-gray-300 text-xs leading-relaxed truncate">{item.preview}</p>
                        </button>
                        <div className="flex items-center gap-2 mt-1">
                          <span className={`text-xs px-1.5 py-0.5 rounded font-medium ${CATEGORY_COLORS[item.category] || 'bg-gray-700 text-gray-400'}`}>
                            {item.category}
                          </span>
                          <span className="text-gray-600 text-xs">{item.chars.toLocaleString()} chars</span>
                          <span className="text-gray-600 text-xs">{item.time}</span>
                          {clipPinned.has(item.id) && <Pin size={10} className="text-yellow-400 fill-yellow-400" />}
                        </div>
                      </div>
                      <div className="flex gap-1 shrink-0">
                        <button onClick={() => togglePin(item.id)}
                          className={`p-1 rounded hover:bg-gray-600/50 ${clipPinned.has(item.id) ? 'text-yellow-400' : 'text-gray-600'}`}>
                          <Pin size={12} />
                        </button>
                        <button onClick={() => deleteClip(item.id)}
                          className="p-1 rounded hover:bg-red-500/20 text-gray-600 hover:text-red-400">
                          <Trash2 size={12} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Bottom navigation */}
          <div className="flex items-center border-t border-gray-700/40 bg-gray-900/50">
            <button onClick={() => setPanel('qwerty')}
              className={`flex-1 py-2.5 flex flex-col items-center gap-0.5 transition-colors ${
                panel === 'qwerty' ? 'text-blue-400' : 'text-gray-600 hover:text-gray-400'
              }`}>
              <span className="text-xs font-medium">⌨️</span>
              <span className="text-xs" style={{ fontSize: 9 }}>Keys</span>
            </button>
            <button onClick={() => setPanel('emoji')}
              className={`flex-1 py-2.5 flex flex-col items-center gap-0.5 transition-colors ${
                panel === 'emoji' ? 'text-blue-400' : 'text-gray-600 hover:text-gray-400'
              }`}>
              <Smile size={14} />
              <span style={{ fontSize: 9 }}>Emoji</span>
            </button>
            <button onClick={() => setPanel('clipboard')}
              className={`flex-1 py-2.5 flex flex-col items-center gap-0.5 transition-colors ${
                panel === 'clipboard' ? 'text-blue-400' : 'text-gray-600 hover:text-gray-400'
              }`}>
              <Clipboard size={14} />
              <span style={{ fontSize: 9 }}>Clip</span>
            </button>
            <button
              className="flex-1 py-2.5 flex flex-col items-center gap-0.5 text-gray-600 hover:text-gray-400 transition-colors">
              <Settings size={14} />
              <span style={{ fontSize: 9 }}>Settings</span>
            </button>
          </div>
        </div>
      </div>

      {/* Instructions */}
      <div className="flex flex-wrap gap-2 justify-center max-w-sm">
        {[
          { icon: '⌨️', text: 'Type normally' },
          { icon: '😂', text: 'Hold emoji = rapid fire' },
          { icon: '📋', text: 'Tap clipboard to paste' },
          { icon: '⬆', text: 'Double shift = CAPS' },
        ].map(h => (
          <div key={h.text} className="flex items-center gap-1 bg-gray-800/60 rounded-full px-3 py-1 border border-gray-700/50">
            <span className="text-sm">{h.icon}</span>
            <span className="text-gray-400 text-xs">{h.text}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
