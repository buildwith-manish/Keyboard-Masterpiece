export type TabId =
  | 'overview'
  | 'demo'
  | 'architecture'
  | 'ime'
  | 'emoji'
  | 'clipboard'
  | 'performance'
  | 'theme'
  | 'database'
  | 'security'
  | 'build';

export interface Tab {
  id: TabId;
  label: string;
  icon: string;
}

export interface CodeFile {
  name: string;
  language: string;
  code: string;
  description: string;
}

export interface Feature {
  icon: string;
  title: string;
  description: string;
  badge?: string;
}

export interface Metric {
  label: string;
  value: string;
  unit?: string;
  color: string;
}
