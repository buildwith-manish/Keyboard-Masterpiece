import { Card } from './ui/Card';
import { Badge } from './ui/Badge';

const features = {
  gboard: [
    { name: 'Swipe Typing', priority: 'high', complexity: 'high', status: 'new' },
    { name: 'AI Autocorrect', priority: 'critical', complexity: 'high', status: 'new' },
    { name: 'Smart Prediction Bar', priority: 'high', complexity: 'medium', status: 'new' },
    { name: 'Emoji Suggestions', priority: 'medium', complexity: 'medium', status: 'new' },
    { name: 'GIF/Sticker Support', priority: 'medium', complexity: 'medium', status: 'new' },
    { name: 'Floating Keyboard', priority: 'medium', complexity: 'low', status: 'new' },
    { name: 'One-Handed Mode', priority: 'high', complexity: 'medium', status: 'new' },
    { name: 'Multilingual Typing', priority: 'high', complexity: 'high', status: 'enhance' },
    { name: 'Voice Typing Hooks', priority: 'medium', complexity: 'medium', status: 'new' },
    { name: 'Gesture Delete', priority: 'low', complexity: 'low', status: 'new' },
    { name: 'Clipboard Manager', priority: 'high', complexity: 'medium', status: 'enhance' },
  ],
  swiftkey: [
    { name: 'Adaptive Learning', priority: 'critical', complexity: 'high', status: 'new' },
    { name: 'Advanced Prediction Engine', priority: 'critical', complexity: 'high', status: 'enhance' },
    { name: 'Multilingual Auto-Switch', priority: 'high', complexity: 'high', status: 'new' },
    { name: 'Personalized Suggestions', priority: 'high', complexity: 'high', status: 'new' },
    { name: 'Cloud Sync Architecture', priority: 'medium', complexity: 'high', status: 'new' },
  ],
  fleksy: [
    { name: 'Ultra-Low Latency Engine', priority: 'critical', complexity: 'high', status: 'new' },
    { name: 'Gesture Shortcuts', priority: 'high', complexity: 'medium', status: 'new' },
    { name: 'Performance Optimizations', priority: 'critical', complexity: 'high', status: 'enhance' },
    { name: 'Lightweight Architecture', priority: 'high', complexity: 'medium', status: 'enhance' },
  ],
  grammarly: [
    { name: 'Grammar Suggestions', priority: 'high', complexity: 'high', status: 'new' },
    { name: 'Punctuation Correction', priority: 'medium', complexity: 'medium', status: 'new' },
    { name: 'Writing Clarity', priority: 'medium', complexity: 'high', status: 'new' },
    { name: 'Tone Suggestion System', priority: 'low', complexity: 'high', status: 'new' },
  ],
  samsung: [
    { name: 'Premium Themes', priority: 'high', complexity: 'medium', status: 'enhance' },
    { name: 'Split Keyboard Mode', priority: 'medium', complexity: 'medium', status: 'new' },
    { name: 'Keyboard Resizing', priority: 'medium', complexity: 'low', status: 'new' },
    { name: 'Clipboard Pinning', priority: 'low', complexity: 'low', status: 'new' },
    { name: 'Polished UI Animations', priority: 'high', complexity: 'medium', status: 'enhance' },
  ],
};

export function FeatureMatrix() {
  const allFeatures = Object.entries(features).flatMap(([source, feats]) =>
    feats.map(f => ({ ...f, source }))
  );

  const totalFeatures = allFeatures.length;
  const newFeatures = allFeatures.filter(f => f.status === 'new').length;
  const enhancements = allFeatures.filter(f => f.status === 'enhance').length;
  const criticalFeatures = allFeatures.filter(f => f.priority === 'critical').length;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-4xl font-bold text-white mb-2">
          ⭐ Premium Feature Matrix
        </h1>
        <p className="text-gray-400">
          Best-in-class features from leading keyboard apps
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-purple-900/30 to-purple-800/30">
          <div className="text-3xl font-bold text-white mb-1">{totalFeatures}</div>
          <div className="text-sm text-purple-300">Total Features</div>
        </Card>
        <Card className="bg-gradient-to-br from-green-900/30 to-green-800/30">
          <div className="text-3xl font-bold text-white mb-1">{newFeatures}</div>
          <div className="text-sm text-green-300">New Modules</div>
        </Card>
        <Card className="bg-gradient-to-br from-blue-900/30 to-blue-800/30">
          <div className="text-3xl font-bold text-white mb-1">{enhancements}</div>
          <div className="text-sm text-blue-300">Enhancements</div>
        </Card>
        <Card className="bg-gradient-to-br from-red-900/30 to-red-800/30">
          <div className="text-3xl font-bold text-white mb-1">{criticalFeatures}</div>
          <div className="text-sm text-red-300">Critical Priority</div>
        </Card>
      </div>

      {/* Gboard Features */}
      <Card>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center text-2xl">
            G
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white">Gboard Features</h2>
            <p className="text-sm text-gray-400">Google's flagship keyboard capabilities</p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {features.gboard.map((feature) => (
            <FeatureCard key={feature.name} feature={feature} />
          ))}
        </div>
      </Card>

      {/* SwiftKey Features */}
      <Card>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-lg flex items-center justify-center text-2xl">
            SK
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white">SwiftKey Features</h2>
            <p className="text-sm text-gray-400">AI-powered prediction excellence</p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {features.swiftkey.map((feature) => (
            <FeatureCard key={feature.name} feature={feature} />
          ))}
        </div>
      </Card>

      {/* Fleksy Features */}
      <Card>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg flex items-center justify-center text-2xl">
            F
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white">Fleksy Features</h2>
            <p className="text-sm text-gray-400">Ultra-fast performance focus</p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {features.fleksy.map((feature) => (
            <FeatureCard key={feature.name} feature={feature} />
          ))}
        </div>
      </Card>

      {/* Grammarly Features */}
      <Card>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 bg-gradient-to-br from-yellow-500 to-yellow-600 rounded-lg flex items-center justify-center text-2xl">
            Gr
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white">Grammarly Features</h2>
            <p className="text-sm text-gray-400">Writing assistance intelligence</p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {features.grammarly.map((feature) => (
            <FeatureCard key={feature.name} feature={feature} />
          ))}
        </div>
      </Card>

      {/* Samsung Features */}
      <Card>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-lg flex items-center justify-center text-2xl">
            S
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white">Samsung Keyboard Features</h2>
            <p className="text-sm text-gray-400">Premium UI/UX polish</p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {features.samsung.map((feature) => (
            <FeatureCard key={feature.name} feature={feature} />
          ))}
        </div>
      </Card>
    </div>
  );
}

function FeatureCard({ feature }: { feature: any }) {
  return (
    <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700 hover:border-purple-500/30 transition-colors">
      <div className="flex items-start justify-between mb-2">
        <h3 className="font-semibold text-white">{feature.name}</h3>
        <Badge variant={feature.status === 'new' ? 'success' : 'warning'}>
          {feature.status === 'new' ? 'NEW' : 'ENHANCE'}
        </Badge>
      </div>
      <div className="flex gap-2">
        <Badge variant={
          feature.priority === 'critical' ? 'critical' :
          feature.priority === 'high' ? 'warning' : 'neutral'
        }>
          {feature.priority}
        </Badge>
        <Badge variant="neutral">
          {feature.complexity} complexity
        </Badge>
      </div>
    </div>
  );
}
