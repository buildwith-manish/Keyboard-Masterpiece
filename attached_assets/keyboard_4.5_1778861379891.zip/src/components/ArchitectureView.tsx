import { Card } from './ui/Card';
import { Badge } from './ui/Badge';

const architectureLayers = [
  {
    name: 'Presentation Layer',
    components: [
      { name: 'KeyboardView (Flutter)', file: 'lib/widgets/keyboard_view.dart', status: 'enhance' },
      { name: 'ThemeManager', file: 'lib/managers/theme_manager.dart', status: 'fix' },
      { name: 'AnimationController', file: 'lib/controllers/animation_controller.dart', status: 'enhance' },
      { name: 'GestureHandler', file: 'lib/handlers/gesture_handler.dart', status: 'new' },
    ],
  },
  {
    name: 'Business Logic Layer',
    components: [
      { name: 'InputMethodService', file: 'android/app/src/main/kotlin/InputService.kt', status: 'fix' },
      { name: 'PredictionEngine', file: 'lib/engines/prediction_engine.dart', status: 'enhance' },
      { name: 'AutocorrectEngine', file: 'lib/engines/autocorrect_engine.dart', status: 'new' },
      { name: 'GrammarEngine', file: 'lib/engines/grammar_engine.dart', status: 'new' },
      { name: 'SwipeEngine', file: 'lib/engines/swipe_engine.dart', status: 'new' },
    ],
  },
  {
    name: 'Data Layer',
    components: [
      { name: 'DictionaryRepository', file: 'lib/repositories/dictionary_repository.dart', status: 'enhance' },
      { name: 'UserPreferencesRepository', file: 'lib/repositories/preferences_repository.dart', status: 'enhance' },
      { name: 'ClipboardRepository', file: 'lib/repositories/clipboard_repository.dart', status: 'new' },
      { name: 'LocalDatabase', file: 'lib/data/local_database.dart', status: 'enhance' },
    ],
  },
  {
    name: 'Platform Layer',
    components: [
      { name: 'AccessibilityService', file: 'android/app/src/main/kotlin/AccessibilityService.kt', status: 'enhance' },
      { name: 'PermissionHandler', file: 'android/app/src/main/kotlin/PermissionHandler.kt', status: 'new' },
      { name: 'MethodChannel Bridge', file: 'lib/platform/method_channel.dart', status: 'enhance' },
      { name: 'NotificationManager', file: 'android/app/src/main/kotlin/NotificationManager.kt', status: 'new' },
    ],
  },
];

const newModules = [
  {
    name: 'SwipeTypingModule',
    description: 'Gesture-based typing with ML path recognition',
    files: [
      'lib/modules/swipe/swipe_detector.dart',
      'lib/modules/swipe/swipe_predictor.dart',
      'lib/modules/swipe/swipe_ui.dart',
      'assets/ml_models/swipe_model.tflite',
    ],
    dependencies: ['tflite_flutter', 'ml_kit'],
  },
  {
    name: 'AIAutocorrectModule',
    description: 'Context-aware autocorrection with transformer models',
    files: [
      'lib/modules/autocorrect/ai_corrector.dart',
      'lib/modules/autocorrect/context_analyzer.dart',
      'lib/modules/autocorrect/correction_ui.dart',
      'assets/ml_models/autocorrect_model.tflite',
    ],
    dependencies: ['tflite_flutter', 'dart:isolate'],
  },
  {
    name: 'ClipboardManagerModule',
    description: 'Advanced clipboard with history and pinning',
    files: [
      'lib/modules/clipboard/clipboard_manager.dart',
      'lib/modules/clipboard/clipboard_ui.dart',
      'lib/modules/clipboard/clipboard_database.dart',
    ],
    dependencies: ['sqflite', 'clipboard'],
  },
  {
    name: 'GrammarAssistantModule',
    description: 'Real-time grammar and writing suggestions',
    files: [
      'lib/modules/grammar/grammar_checker.dart',
      'lib/modules/grammar/grammar_rules.dart',
      'lib/modules/grammar/grammar_ui.dart',
    ],
    dependencies: ['language_tool'],
  },
  {
    name: 'PerformanceOptimizationModule',
    description: 'Frame rate optimization and memory management',
    files: [
      'lib/modules/performance/render_optimizer.dart',
      'lib/modules/performance/memory_manager.dart',
      'lib/modules/performance/profiler.dart',
    ],
    dependencies: [],
  },
];

export function ArchitectureView() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-4xl font-bold text-white mb-2">
          🏗️ System Architecture
        </h1>
        <p className="text-gray-400">
          Enhanced modular architecture with clean separation of concerns
        </p>
      </div>

      {/* Architecture Diagram */}
      <Card className="bg-gradient-to-br from-purple-900/20 to-pink-900/20">
        <h2 className="text-2xl font-bold text-white mb-6">Layered Architecture</h2>
        
        <div className="space-y-4">
          {architectureLayers.map((layer) => (
            <div key={layer.name} className="border border-purple-500/30 rounded-lg overflow-hidden">
              <div className="bg-purple-500/10 px-4 py-3 border-b border-purple-500/30">
                <h3 className="text-lg font-semibold text-white">{layer.name}</h3>
              </div>
              <div className="p-4 space-y-2">
                {layer.components.map((component) => (
                  <div
                    key={component.name}
                    className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg"
                  >
                    <div className="flex-1">
                      <div className="font-semibold text-white text-sm">{component.name}</div>
                      <div className="text-xs text-gray-400 font-mono mt-1">{component.file}</div>
                    </div>
                    <Badge variant={
                      component.status === 'new' ? 'success' :
                      component.status === 'fix' ? 'critical' : 'warning'
                    }>
                      {component.status.toUpperCase()}
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* New Modules */}
      <Card>
        <h2 className="text-2xl font-bold text-white mb-6">New Feature Modules</h2>
        
        <div className="space-y-4">
          {newModules.map((module) => (
            <div
              key={module.name}
              className="p-5 bg-slate-800/50 rounded-lg border border-green-500/20"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="text-lg font-semibold text-white mb-1">{module.name}</h3>
                  <p className="text-sm text-gray-400">{module.description}</p>
                </div>
                <Badge variant="success">NEW MODULE</Badge>
              </div>

              <div className="mt-4">
                <div className="text-sm font-semibold text-purple-300 mb-2">Files to Create:</div>
                <div className="space-y-1">
                  {module.files.map((file) => (
                    <div key={file} className="text-xs font-mono text-gray-400 pl-4">
                      ✓ {file}
                    </div>
                  ))}
                </div>
              </div>

              {module.dependencies.length > 0 && (
                <div className="mt-3 pt-3 border-t border-slate-700">
                  <div className="text-sm font-semibold text-blue-300 mb-2">Dependencies:</div>
                  <div className="flex flex-wrap gap-2">
                    {module.dependencies.map((dep) => (
                      <code key={dep} className="text-xs px-2 py-1 bg-blue-500/10 text-blue-300 rounded border border-blue-500/30">
                        {dep}
                      </code>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </Card>

      {/* Data Flow */}
      <Card>
        <h2 className="text-2xl font-bold text-white mb-6">Data Flow Architecture</h2>
        
        <div className="space-y-6">
          <div className="p-4 bg-gradient-to-r from-blue-900/30 to-purple-900/30 rounded-lg border border-blue-500/30">
            <div className="font-semibold text-blue-300 mb-3">User Input → Processing Pipeline</div>
            <div className="space-y-2 text-sm text-gray-300">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-blue-500/20 rounded-full flex items-center justify-center text-xs">1</div>
                <div>Key Press / Swipe Gesture → GestureHandler</div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-blue-500/20 rounded-full flex items-center justify-center text-xs">2</div>
                <div>Input Processing → InputMethodService (Main Thread)</div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-blue-500/20 rounded-full flex items-center justify-center text-xs">3</div>
                <div>Prediction Request → PredictionEngine (Background Isolate)</div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-blue-500/20 rounded-full flex items-center justify-center text-xs">4</div>
                <div>Grammar Check → GrammarEngine (Background Isolate)</div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-blue-500/20 rounded-full flex items-center justify-center text-xs">5</div>
                <div>UI Update → KeyboardView (60fps Rendering)</div>
              </div>
            </div>
          </div>

          <div className="p-4 bg-gradient-to-r from-green-900/30 to-teal-900/30 rounded-lg border border-green-500/30">
            <div className="font-semibold text-green-300 mb-3">State Management</div>
            <div className="space-y-2 text-sm text-gray-300">
              <div>✓ Riverpod for global state management</div>
              <div>✓ StateNotifier for keyboard state</div>
              <div>✓ StreamController for real-time updates</div>
              <div>✓ ChangeNotifier for theme and preferences</div>
            </div>
          </div>

          <div className="p-4 bg-gradient-to-r from-purple-900/30 to-pink-900/30 rounded-lg border border-purple-500/30">
            <div className="font-semibold text-purple-300 mb-3">Background Processing</div>
            <div className="space-y-2 text-sm text-gray-300">
              <div>✓ Isolates for ML model inference</div>
              <div>✓ Compute for heavy calculations</div>
              <div>✓ WorkManager for periodic tasks</div>
              <div>✓ Debouncing for expensive operations</div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
