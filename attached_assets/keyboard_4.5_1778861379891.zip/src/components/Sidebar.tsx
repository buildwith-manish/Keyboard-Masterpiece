import { cn } from '../utils/cn';

type Tab = 'audit' | 'features' | 'architecture' | 'files' | 'implementation' | 'code' | 'performance' | 'testing' | 'package';

interface SidebarProps {
  activeTab: Tab;
  setActiveTab: (tab: Tab) => void;
}

const menuItems: { id: Tab; label: string; icon: string; description: string }[] = [
  { id: 'audit', label: 'Audit Report', icon: '🔍', description: 'Comprehensive analysis' },
  { id: 'features', label: 'Feature Matrix', icon: '⭐', description: 'Premium features' },
  { id: 'architecture', label: 'Architecture', icon: '🏗️', description: 'System design' },
  { id: 'files', label: 'File Structure', icon: '📁', description: 'Repository layout' },
  { id: 'implementation', label: 'Implementation', icon: '⚙️', description: 'Integration guide' },
  { id: 'code', label: 'Code Enhancements', icon: '💻', description: 'New modules' },
  { id: 'performance', label: 'Performance', icon: '⚡', description: 'Optimization metrics' },
  { id: 'testing', label: 'Testing', icon: '🧪', description: 'QA strategy' },
  { id: 'package', label: 'Deployment', icon: '📦', description: 'Final package' },
];

export function Sidebar({ activeTab, setActiveTab }: SidebarProps) {
  return (
    <aside className="w-80 bg-slate-950/90 backdrop-blur-xl border-r border-purple-500/20 flex flex-col">
      <div className="p-6 border-b border-purple-500/20">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center text-2xl">
            ⌨️
          </div>
          <div>
            <h1 className="text-xl font-bold text-white">Keyboard Elite</h1>
            <p className="text-xs text-purple-300">Enhancement Suite</p>
          </div>
        </div>
        <div className="mt-4 px-3 py-2 bg-purple-500/10 rounded-lg border border-purple-500/30">
          <p className="text-xs text-purple-200 font-mono">Target: Keyboard-Masterpiece</p>
          <p className="text-xs text-gray-400 mt-1">buildwith-manish</p>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto p-4 space-y-1">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={cn(
              'w-full text-left px-4 py-3 rounded-lg transition-all duration-200',
              'flex items-start gap-3 group',
              activeTab === item.id
                ? 'bg-gradient-to-r from-purple-500/20 to-pink-500/20 border border-purple-400/40 shadow-lg shadow-purple-500/10'
                : 'hover:bg-white/5 border border-transparent hover:border-purple-500/20'
            )}
          >
            <span className="text-2xl mt-0.5">{item.icon}</span>
            <div className="flex-1 min-w-0">
              <div className={cn(
                'font-semibold text-sm',
                activeTab === item.id ? 'text-white' : 'text-gray-300 group-hover:text-white'
              )}>
                {item.label}
              </div>
              <div className="text-xs text-gray-500 group-hover:text-gray-400 mt-0.5">
                {item.description}
              </div>
            </div>
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-purple-500/20">
        <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-3">
          <div className="flex items-center gap-2 mb-1">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            <span className="text-xs font-semibold text-green-300">Analysis Complete</span>
          </div>
          <p className="text-xs text-gray-400">Ready for deployment</p>
        </div>
      </div>
    </aside>
  );
}
