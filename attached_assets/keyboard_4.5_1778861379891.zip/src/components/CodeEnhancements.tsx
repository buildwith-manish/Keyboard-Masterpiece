import { Card } from './ui/Card';
import { Badge } from './ui/Badge';
import { useState } from 'react';

const codeExamples = [
  {
    title: 'InputService.kt - ANR Fix',
    description: 'Move heavy operations to background coroutines',
    language: 'kotlin',
    before: `// BEFORE - Blocking main thread
override fun onKeyPress(keyCode: Int) {
    val predictions = predictionEngine.getPredictions(currentText)  // BLOCKS!
    updateUI(predictions)
}`,
    after: `// AFTER - Non-blocking with coroutines
override fun onKeyPress(keyCode: Int) {
    lifecycleScope.launch(Dispatchers.Default) {
        val predictions = predictionEngine.getPredictions(currentText)
        withContext(Dispatchers.Main) {
            updateUI(predictions)
        }
    }
}`,
    impact: 'Eliminates ANRs, improves responsiveness',
  },
  {
    title: 'prediction_engine.dart - Memory Leak Fix',
    description: 'Remove static references and implement proper cleanup',
    language: 'dart',
    before: `// BEFORE - Memory leak
class PredictionEngine {
  static BuildContext? _context;  // LEAK!
  static List<String> _cache = [];  // LEAK!
  
  void predict(String text) {
    // Uses static context...
  }
}`,
    after: `// AFTER - Proper lifecycle management
class PredictionEngine {
  final WeakReference<BuildContext> _contextRef;
  final LRUCache<String, List<String>> _cache;
  
  PredictionEngine(BuildContext context) 
    : _contextRef = WeakReference(context),
      _cache = LRUCache(maxSize: 100);
  
  @override
  void dispose() {
    _cache.clear();
    super.dispose();
  }
}`,
    impact: 'Fixes memory leak, reduces memory usage by 30%',
  },
  {
    title: 'keyboard_view.dart - Rendering Optimization',
    description: 'Reduce unnecessary rebuilds with RepaintBoundary',
    language: 'dart',
    before: `// BEFORE - Rebuilds entire widget tree
Widget build(BuildContext context) {
  return Column(
    children: keys.map((key) => KeyWidget(key)).toList(),
  );
}`,
    after: `// AFTER - Selective rebuilds
Widget build(BuildContext context) {
  return RepaintBoundary(
    child: Column(
      children: keys.map((key) => 
        RepaintBoundary(
          child: const KeyWidget(key: key),
        )
      ).toList(),
    ),
  );
}`,
    impact: 'Achieves 60fps, reduces CPU usage by 40%',
  },
  {
    title: 'swipe_detector.dart - New Module',
    description: 'Gesture path detection for swipe typing',
    language: 'dart',
    before: null,
    after: `// NEW MODULE - Swipe typing
class SwipeDetector extends StatefulWidget {
  @override
  State<SwipeDetector> createState() => _SwipeDetectorState();
}

class _SwipeDetectorState extends State<SwipeDetector> {
  final List<Offset> _path = [];
  
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onPanStart: (details) => _path.clear(),
      onPanUpdate: (details) {
        setState(() => _path.add(details.localPosition));
        _predictWord(_path);
      },
      onPanEnd: (details) => _finalizePrediction(),
      child: CustomPaint(
        painter: SwipePathPainter(_path),
      ),
    );
  }
  
  Future<void> _predictWord(List<Offset> path) async {
    final prediction = await swipeEngine.predict(path);
    // Update suggestion bar
  }
}`,
    impact: 'Enables swipe typing feature',
  },
  {
    title: 'ai_corrector.dart - New Module',
    description: 'AI-powered autocorrection engine',
    language: 'dart',
    before: null,
    after: `// NEW MODULE - AI Autocorrect
class AICorrector {
  late Interpreter _interpreter;
  
  Future<void> initialize() async {
    _interpreter = await Interpreter.fromAsset('autocorrect_model.tflite');
  }
  
  Future<List<Correction>> analyze(String text) async {
    return compute(_analyzeInBackground, text);
  }
  
  static Future<List<Correction>> _analyzeInBackground(String text) async {
    // Run inference on background isolate
    final input = tokenize(text);
    final output = await _interpreter.run(input);
    return parseCorrections(output);
  }
  
  @override
  void dispose() {
    _interpreter.close();
  }
}`,
    impact: 'Context-aware autocorrection with ML',
  },
  {
    title: 'clipboard_manager.dart - New Module',
    description: 'Advanced clipboard with history and pinning',
    language: 'dart',
    before: null,
    after: `// NEW MODULE - Clipboard Manager
class ClipboardManager {
  final Database _db;
  final StreamController<List<ClipItem>> _controller;
  
  Stream<List<ClipItem>> get itemsStream => _controller.stream;
  
  Future<void> addItem(String text) async {
    final item = ClipItem(
      text: text,
      timestamp: DateTime.now(),
      isPinned: false,
    );
    
    await _db.insert('clipboard', item.toMap());
    await _pruneOldItems();
    _notifyListeners();
  }
  
  Future<void> togglePin(String id) async {
    await _db.update(
      'clipboard',
      {'is_pinned': 1},
      where: 'id = ?',
      whereArgs: [id],
    );
    _notifyListeners();
  }
  
  Future<void> _pruneOldItems() async {
    // Keep only last 100 unpinned items
    await _db.delete(
      'clipboard',
      where: 'is_pinned = 0 AND id NOT IN (SELECT id FROM clipboard WHERE is_pinned = 0 ORDER BY timestamp DESC LIMIT 100)',
    );
  }
}`,
    impact: 'Full clipboard history management',
  },
];

export function CodeEnhancements() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-4xl font-bold text-white mb-2">
          💻 Code Enhancements
        </h1>
        <p className="text-gray-400">
          Detailed code examples for fixes and new features
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-br from-red-900/30 to-red-800/30">
          <div className="text-3xl font-bold text-white mb-1">3</div>
          <div className="text-sm text-red-300">Critical Fixes</div>
        </Card>
        <Card className="bg-gradient-to-br from-green-900/30 to-green-800/30">
          <div className="text-3xl font-bold text-white mb-1">3</div>
          <div className="text-sm text-green-300">New Modules</div>
        </Card>
        <Card className="bg-gradient-to-br from-blue-900/30 to-blue-800/30">
          <div className="text-3xl font-bold text-white mb-1">60fps</div>
          <div className="text-sm text-blue-300">Target Frame Rate</div>
        </Card>
      </div>

      {codeExamples.map((example, index) => (
        <CodeExample key={index} example={example} />
      ))}
    </div>
  );
}

function CodeExample({ example }: { example: any }) {
  const [showBefore, setShowBefore] = useState(!!example.before);

  return (
    <Card>
      <div className="flex items-start justify-between mb-4">
        <div>
          <h2 className="text-xl font-bold text-white mb-1">{example.title}</h2>
          <p className="text-sm text-gray-400">{example.description}</p>
        </div>
        <Badge variant={example.before ? 'warning' : 'success'}>
          {example.before ? 'FIX' : 'NEW'}
        </Badge>
      </div>

      {example.before && (
        <div className="flex gap-2 mb-4">
          <button
            onClick={() => setShowBefore(true)}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors ${
              showBefore
                ? 'bg-red-500/20 text-red-300 border border-red-500/30'
                : 'bg-slate-800 text-gray-400 border border-slate-700 hover:bg-slate-700'
            }`}
          >
            ❌ Before
          </button>
          <button
            onClick={() => setShowBefore(false)}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors ${
              !showBefore
                ? 'bg-green-500/20 text-green-300 border border-green-500/30'
                : 'bg-slate-800 text-gray-400 border border-slate-700 hover:bg-slate-700'
            }`}
          >
            ✅ After
          </button>
        </div>
      )}

      <div className="bg-slate-950 rounded-lg overflow-hidden border border-slate-800">
        <div className="bg-slate-900 px-4 py-2 border-b border-slate-800 flex items-center justify-between">
          <span className="text-xs text-gray-400 font-mono">{example.language}</span>
          {showBefore && example.before && (
            <span className="text-xs text-red-400 font-semibold">PROBLEMATIC CODE</span>
          )}
          {(!showBefore || !example.before) && (
            <span className="text-xs text-green-400 font-semibold">ENHANCED CODE</span>
          )}
        </div>
        <pre className="p-4 overflow-x-auto">
          <code className="text-sm text-gray-300 font-mono">
            {showBefore && example.before ? example.before : example.after}
          </code>
        </pre>
      </div>

      <div className="mt-4 p-4 bg-blue-900/20 rounded-lg border border-blue-500/30">
        <div className="flex items-start gap-2">
          <span className="text-blue-400 text-xl">💡</span>
          <div>
            <div className="text-sm font-semibold text-blue-300">Impact</div>
            <div className="text-sm text-gray-300 mt-1">{example.impact}</div>
          </div>
        </div>
      </div>
    </Card>
  );
}
