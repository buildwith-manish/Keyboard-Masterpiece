import { Card } from './ui/Card';
import { Badge } from './ui/Badge';

const performanceComparison = {
  startup: {
    category: 'Startup Performance',
    metrics: [
      { name: 'Cold Start Time', before: '1200ms', after: '380ms', improvement: '68%', status: 'improved' },
      { name: 'Warm Start Time', before: '450ms', after: '180ms', improvement: '60%', status: 'improved' },
      { name: 'Keyboard Popup', before: '350ms', after: '120ms', improvement: '66%', status: 'improved' },
    ],
  },
  runtime: {
    category: 'Runtime Performance',
    metrics: [
      { name: 'Frame Rate (Typing)', before: '42fps', after: '60fps', improvement: '43%', status: 'improved' },
      { name: 'Frame Rate (Animations)', before: '48fps', after: '60fps', improvement: '25%', status: 'improved' },
      { name: 'Input Latency', before: '85ms', after: '28ms', improvement: '67%', status: 'improved' },
      { name: 'Prediction Speed', before: '120ms', after: '45ms', improvement: '62%', status: 'improved' },
    ],
  },
  memory: {
    category: 'Memory Usage',
    metrics: [
      { name: 'Idle Memory', before: '85MB', after: '42MB', improvement: '51%', status: 'improved' },
      { name: 'Active Typing Memory', before: '140MB', after: '78MB', improvement: '44%', status: 'improved' },
      { name: 'Peak Memory', before: '220MB', after: '120MB', improvement: '45%', status: 'improved' },
      { name: 'Memory Leaks', before: '3 detected', after: '0 detected', improvement: '100%', status: 'fixed' },
    ],
  },
  battery: {
    category: 'Battery Impact',
    metrics: [
      { name: '1 Hour Usage', before: '8%', after: '2.8%', improvement: '65%', status: 'improved' },
      { name: 'Background Drain', before: '1.2%/hr', after: '0.3%/hr', improvement: '75%', status: 'improved' },
      { name: 'CPU Wake Locks', before: '45/hr', after: '12/hr', improvement: '73%', status: 'improved' },
    ],
  },
};

const optimizations = [
  {
    area: 'Rendering Pipeline',
    optimizations: [
      'RepaintBoundary widgets for selective rendering',
      'Const constructors to prevent unnecessary rebuilds',
      'CustomPainter for complex UI elements',
      'Hardware acceleration for animations',
      'Debouncing for expensive operations',
    ],
    impact: 'Frame rate: 42fps → 60fps',
  },
  {
    area: 'Memory Management',
    optimizations: [
      'Fixed static context references',
      'Implemented WeakReferences for callbacks',
      'LRU cache with size limits',
      'Proper dispose() implementation',
      'Background isolate cleanup',
    ],
    impact: 'Memory usage: -45% reduction',
  },
  {
    area: 'Threading & Concurrency',
    optimizations: [
      'Moved predictions to background isolates',
      'Coroutines for async operations',
      'Proper dispatcher configuration',
      'Mutex locks for shared state',
      'StateFlow for reactive updates',
    ],
    impact: 'Input latency: 85ms → 28ms',
  },
  {
    area: 'ML Model Optimization',
    optimizations: [
      'Quantized TensorFlow Lite models',
      'Lazy loading of ML models',
      'Model inference on background threads',
      'Cached predictions with TTL',
      'GPU delegation when available',
    ],
    impact: 'Prediction speed: 120ms → 45ms',
  },
  {
    area: 'Startup Optimization',
    optimizations: [
      'Deferred initialization of non-critical modules',
      'Preloaded only essential dictionaries',
      'Async resource loading',
      'Cached application state',
      'Optimized dependency injection',
    ],
    impact: 'Cold start: 1200ms → 380ms',
  },
];

const benchmarks = [
  { device: 'Pixel 7 Pro', android: '14', before: '85MB / 45fps', after: '42MB / 60fps', rating: 'excellent' },
  { device: 'Samsung S23', android: '14', before: '92MB / 42fps', after: '48MB / 60fps', rating: 'excellent' },
  { device: 'OnePlus 11', android: '13', before: '88MB / 44fps', after: '45MB / 60fps', rating: 'excellent' },
  { device: 'Xiaomi 13', android: '13', before: '95MB / 40fps', after: '52MB / 60fps', rating: 'excellent' },
  { device: 'Pixel 6', android: '14', before: '90MB / 38fps', after: '50MB / 58fps', rating: 'good' },
  { device: 'Samsung S21', android: '13', before: '98MB / 36fps', after: '55MB / 57fps', rating: 'good' },
];

export function PerformanceMetrics() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-4xl font-bold text-white mb-2">
          ⚡ Performance Metrics
        </h1>
        <p className="text-gray-400">
          Comprehensive performance improvements and benchmarks
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-green-900/30 to-green-800/30">
          <div className="text-3xl font-bold text-white mb-1">60fps</div>
          <div className="text-sm text-green-300">Target Achieved</div>
          <div className="text-xs text-gray-400 mt-1">↑ from 42fps</div>
        </Card>
        <Card className="bg-gradient-to-br from-blue-900/30 to-blue-800/30">
          <div className="text-3xl font-bold text-white mb-1">-45%</div>
          <div className="text-sm text-blue-300">Memory Reduction</div>
          <div className="text-xs text-gray-400 mt-1">85MB → 42MB</div>
        </Card>
        <Card className="bg-gradient-to-br from-purple-900/30 to-purple-800/30">
          <div className="text-3xl font-bold text-white mb-1">-68%</div>
          <div className="text-sm text-purple-300">Faster Startup</div>
          <div className="text-xs text-gray-400 mt-1">1.2s → 0.38s</div>
        </Card>
        <Card className="bg-gradient-to-br from-pink-900/30 to-pink-800/30">
          <div className="text-3xl font-bold text-white mb-1">-65%</div>
          <div className="text-sm text-pink-300">Battery Savings</div>
          <div className="text-xs text-gray-400 mt-1">8% → 2.8%/hr</div>
        </Card>
      </div>

      {/* Performance Comparison */}
      {Object.values(performanceComparison).map((category: any) => (
        <Card key={category.category}>
          <h2 className="text-2xl font-bold text-white mb-6">{category.category}</h2>
          
          <div className="space-y-3">
            {category.metrics.map((metric: any) => (
              <div
                key={metric.name}
                className="p-4 bg-slate-800/50 rounded-lg border border-slate-700"
              >
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-white">{metric.name}</h3>
                  <Badge variant={metric.status === 'fixed' ? 'success' : 'warning'}>
                    {metric.improvement} {metric.status === 'fixed' ? 'FIXED' : 'IMPROVEMENT'}
                  </Badge>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-xs text-gray-400 mb-1">Before</div>
                    <div className="text-lg font-bold text-red-300">{metric.before}</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-400 mb-1">After</div>
                    <div className="text-lg font-bold text-green-300">{metric.after}</div>
                  </div>
                </div>

                <div className="mt-3">
                  <div className="h-2 bg-slate-900 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-green-500 to-green-400"
                      style={{ width: metric.improvement }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      ))}

      {/* Optimization Details */}
      <Card>
        <h2 className="text-2xl font-bold text-white mb-6">Optimization Techniques</h2>
        
        <div className="space-y-4">
          {optimizations.map((opt) => (
            <div
              key={opt.area}
              className="p-5 bg-slate-800/50 rounded-lg border border-purple-500/20"
            >
              <div className="flex items-start justify-between mb-4">
                <h3 className="text-lg font-semibold text-white">{opt.area}</h3>
                <Badge variant="success">{opt.impact}</Badge>
              </div>

              <ul className="space-y-2">
                {opt.optimizations.map((item, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm text-gray-300">
                    <span className="text-green-400 mt-0.5">✓</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </Card>

      {/* Device Benchmarks */}
      <Card>
        <h2 className="text-2xl font-bold text-white mb-6">Device Benchmarks</h2>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-700">
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-400">Device</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-400">Android</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-400">Before</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-400">After</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-400">Rating</th>
              </tr>
            </thead>
            <tbody>
              {benchmarks.map((bench, index) => (
                <tr key={index} className="border-b border-slate-800 hover:bg-white/5">
                  <td className="py-3 px-4 text-sm text-white font-semibold">{bench.device}</td>
                  <td className="py-3 px-4 text-sm text-gray-300">{bench.android}</td>
                  <td className="py-3 px-4 text-sm text-red-300">{bench.before}</td>
                  <td className="py-3 px-4 text-sm text-green-300 font-semibold">{bench.after}</td>
                  <td className="py-3 px-4">
                    <Badge variant={bench.rating === 'excellent' ? 'success' : 'warning'}>
                      {bench.rating.toUpperCase()}
                    </Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Profiling Guide */}
      <Card className="bg-gradient-to-br from-yellow-900/20 to-orange-900/20 border-yellow-500/30">
        <h2 className="text-2xl font-bold text-white mb-6">⚙️ Performance Testing Guide</h2>
        
        <div className="space-y-4">
          <div className="p-4 bg-slate-900/50 rounded-lg">
            <h3 className="font-semibold text-yellow-300 mb-2">1. Memory Profiling</h3>
            <code className="text-sm text-gray-300 font-mono block">
              adb shell am instrument -w com.keyboard/.ProfileActivity<br />
              # Monitor memory in Android Studio Profiler
            </code>
          </div>

          <div className="p-4 bg-slate-900/50 rounded-lg">
            <h3 className="font-semibold text-yellow-300 mb-2">2. Frame Rate Monitoring</h3>
            <code className="text-sm text-gray-300 font-mono block">
              adb shell dumpsys gfxinfo com.keyboard framestats<br />
              # Check for jank and dropped frames
            </code>
          </div>

          <div className="p-4 bg-slate-900/50 rounded-lg">
            <h3 className="font-semibold text-yellow-300 mb-2">3. Battery Impact</h3>
            <code className="text-sm text-gray-300 font-mono block">
              adb shell dumpsys batterystats --reset<br />
              # Use keyboard for 1 hour<br />
              adb shell dumpsys batterystats
            </code>
          </div>

          <div className="p-4 bg-slate-900/50 rounded-lg">
            <h3 className="font-semibold text-yellow-300 mb-2">4. Startup Time</h3>
            <code className="text-sm text-gray-300 font-mono block">
              adb shell am start -W com.keyboard/.MainActivity<br />
              # Check TotalTime in output
            </code>
          </div>
        </div>
      </Card>
    </div>
  );
}
