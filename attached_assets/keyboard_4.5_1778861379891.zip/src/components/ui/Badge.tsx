import { ReactNode } from 'react';
import { cn } from '../../utils/cn';

interface BadgeProps {
  children: ReactNode;
  variant?: 'critical' | 'warning' | 'success' | 'neutral' | 'high';
  className?: string;
}

export function Badge({ children, variant = 'neutral', className }: BadgeProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold',
        variant === 'critical' && 'bg-red-500/20 text-red-300 border border-red-500/30',
        variant === 'warning' && 'bg-yellow-500/20 text-yellow-300 border border-yellow-500/30',
        variant === 'success' && 'bg-green-500/20 text-green-300 border border-green-500/30',
        variant === 'neutral' && 'bg-slate-500/20 text-slate-300 border border-slate-500/30',
        variant === 'high' && 'bg-orange-500/20 text-orange-300 border border-orange-500/30',
        className
      )}
    >
      {children}
    </span>
  );
}
