import { ReactNode } from 'react';
import { cn } from '../../utils/cn';

interface CardProps {
  children: ReactNode;
  className?: string;
}

export function Card({ children, className }: CardProps) {
  return (
    <div
      className={cn(
        'bg-slate-900/60 backdrop-blur-xl rounded-xl p-6',
        'border border-purple-500/20 shadow-2xl',
        className
      )}
    >
      {children}
    </div>
  );
}
