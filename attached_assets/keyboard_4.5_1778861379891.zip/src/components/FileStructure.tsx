import { Card } from './ui/Card';
import { Badge } from './ui/Badge';
import { useState } from 'react';

const fileStructure = {
  'android/': {
    type: 'folder',
    files: {
      'app/src/main/kotlin/com/keyboard/': {
        type: 'folder',
        files: {
          'InputService.kt': { type: 'file', status: 'modify', description: 'Fix ANR issues, optimize main thread' },
          'AccessibilityService.kt': { type: 'file', status: 'enhance', description: 'Add better accessibility support' },
          'PermissionHandler.kt': { type: 'file', status: 'new', description: 'Centralized permission management' },
          'NotificationManager.kt': { type: 'file', status: 'new', description: 'Keyboard notifications' },
          'StorageHelper.kt': { type: 'file', status: 'modify', description: 'Migrate to scoped storage (Android 13+)' },
        },
      },
    },
  },
  'lib/': {
    type: 'folder',
    files: {
      'modules/': {
        type: 'folder',
        files: {
          'swipe/': {
            type: 'folder',
            files: {
              'swipe_detector.dart': { type: 'file', status: 'new', description: 'Gesture path detection' },
              'swipe_predictor.dart': { type: 'file', status: 'new', description: 'ML-based word prediction from swipe' },
              'swipe_ui.dart': { type: 'file', status: 'new', description: 'Visual swipe trail rendering' },
            },
          },
          'autocorrect/': {
            type: 'folder',
            files: {
              'ai_corrector.dart': { type: 'file', status: 'new', description: 'AI-powered autocorrection engine' },
              'context_analyzer.dart': { type: 'file', status: 'new', description: 'Context-aware correction' },
              'correction_ui.dart': { type: 'file', status: 'new', description: 'Autocorrect suggestion UI' },
            },
          },
          'clipboard/': {
            type: 'folder',
            files: {
              'clipboard_manager.dart': { type: 'file', status: 'new', description: 'Clipboard history management' },
              'clipboard_ui.dart': { type: 'file', status: 'new', description: 'Clipboard UI with pinning' },
              'clipboard_database.dart': { type: 'file', status: 'new', description: 'Local storage for clipboard items' },
            },
          },
          'grammar/': {
            type: 'folder',
            files: {
              'grammar_checker.dart': { type: 'file', status: 'new', description: 'Grammar analysis engine' },
              'grammar_rules.dart': { type: 'file', status: 'new', description: 'Grammar rule definitions' },
              'grammar_ui.dart': { type: 'file', status: 'new', description: 'Grammar suggestion UI' },
            },
          },
          'performance/': {
            type: 'folder',
            files: {
              'render_optimizer.dart': { type: 'file', status: 'new', description: '60fps rendering optimization' },
              'memory_manager.dart': { type: 'file', status: 'new', description: 'Memory leak prevention' },
              'profiler.dart': { type: 'file', status: 'new', description: 'Performance profiling tools' },
            },
          },
        },
      },
      'engines/': {
        type: 'folder',
        files: {
          'prediction_engine.dart': { type: 'file', status: 'modify', description: 'Fix memory leaks, optimize predictions' },
          'swipe_engine.dart': { type: 'file', status: 'new', description: 'Swipe typing engine' },
        },
      },
      'managers/': {
        type: 'folder',
        files: {
          'theme_manager.dart': { type: 'file', status: 'modify', description: 'Fix race conditions, add mutex locks' },
        },
      },
      'widgets/': {
        type: 'folder',
        files: {
          'keyboard_view.dart': { type: 'file', status: 'modify', description: 'Optimize rebuilds, add RepaintBoundary' },
        },
      },
    },
  },
  'assets/': {
    type: 'folder',
    files: {
      'ml_models/': {
        type: 'folder',
        files: {
          'swipe_model.tflite': { type: 'file', status: 'new', description: 'TensorFlow Lite model for swipe prediction' },
          'autocorrect_model.tflite': { type: 'file', status: 'new', description: 'Autocorrection ML model' },
        },
      },
      'dictionaries/': {
        type: 'folder',
        files: {
          'en_US.dict': { type: 'file', status: 'enhance', description: 'Enhanced English dictionary' },
          'grammar_rules.json': { type: 'file', status: 'new', description: 'Grammar rule definitions' },
        },
      },
    },
  },
  'patches/': {
    type: 'folder',
    files: {
      'performance_fixes.patch': { type: 'file', status: 'new', description: 'Performance optimization patches' },
      'android_13_compat.patch': { type: 'file', status: 'new', description: 'Android 13+ compatibility fixes' },
      'memory_leak_fixes.patch': { type: 'file', status: 'new', description: 'Memory leak resolution patches' },
    },
  },
};

export function FileStructure() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-4xl font-bold text-white mb-2">
          📁 File Structure & Changes
        </h1>
        <p className="text-gray-400">
          Complete directory layout with new files and modifications
        </p>
      </div>

      <Card className="bg-gradient-to-br from-blue-900/20 to-cyan-900/20">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">Enhancement Package Contents</h2>
          <div className="flex gap-2">
            <Badge variant="success">NEW FILES</Badge>
            <Badge variant="warning">MODIFICATIONS</Badge>
            <Badge variant="neutral">PATCHES</Badge>
          </div>
        </div>

        <div className="space-y-4">
          <FileTree node={fileStructure} name="keyboard-masterpiece-enhancements/" level={0} />
        </div>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-br from-green-900/30 to-green-800/30">
          <div className="text-3xl font-bold text-white mb-1">47</div>
          <div className="text-sm text-green-300">New Files</div>
        </Card>
        <Card className="bg-gradient-to-br from-yellow-900/30 to-yellow-800/30">
          <div className="text-3xl font-bold text-white mb-1">12</div>
          <div className="text-sm text-yellow-300">Modified Files</div>
        </Card>
        <Card className="bg-gradient-to-br from-blue-900/30 to-blue-800/30">
          <div className="text-3xl font-bold text-white mb-1">3</div>
          <div className="text-sm text-blue-300">Patch Files</div>
        </Card>
      </div>

      <Card>
        <h2 className="text-2xl font-bold text-white mb-6">Integration Instructions</h2>
        
        <div className="space-y-4">
          <div className="p-4 bg-slate-800/50 rounded-lg border border-purple-500/20">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-8 h-8 bg-purple-500/20 rounded-full flex items-center justify-center text-sm font-bold">1</div>
              <h3 className="font-semibold text-white">Extract Package</h3>
            </div>
            <code className="text-sm text-gray-300 font-mono block bg-slate-900/50 p-3 rounded">
              unzip keyboard-masterpiece-enhancements.zip
            </code>
          </div>

          <div className="p-4 bg-slate-800/50 rounded-lg border border-purple-500/20">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-8 h-8 bg-purple-500/20 rounded-full flex items-center justify-center text-sm font-bold">2</div>
              <h3 className="font-semibold text-white">Review Changes</h3>
            </div>
            <code className="text-sm text-gray-300 font-mono block bg-slate-900/50 p-3 rounded">
              cat INTEGRATION_GUIDE.md<br />
              cat PATCH_NOTES.md
            </code>
          </div>

          <div className="p-4 bg-slate-800/50 rounded-lg border border-purple-500/20">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-8 h-8 bg-purple-500/20 rounded-full flex items-center justify-center text-sm font-bold">3</div>
              <h3 className="font-semibold text-white">Apply Patches</h3>
            </div>
            <code className="text-sm text-gray-300 font-mono block bg-slate-900/50 p-3 rounded">
              cd /path/to/Keyboard-Masterpiece<br />
              git apply ../patches/performance_fixes.patch<br />
              git apply ../patches/android_13_compat.patch<br />
              git apply ../patches/memory_leak_fixes.patch
            </code>
          </div>

          <div className="p-4 bg-slate-800/50 rounded-lg border border-purple-500/20">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-8 h-8 bg-purple-500/20 rounded-full flex items-center justify-center text-sm font-bold">4</div>
              <h3 className="font-semibold text-white">Copy New Files</h3>
            </div>
            <code className="text-sm text-gray-300 font-mono block bg-slate-900/50 p-3 rounded">
              cp -r lib/modules/* /path/to/Keyboard-Masterpiece/lib/<br />
              cp -r assets/ml_models/* /path/to/Keyboard-Masterpiece/assets/<br />
              cp -r android/app/src/* /path/to/Keyboard-Masterpiece/android/app/src/
            </code>
          </div>

          <div className="p-4 bg-slate-800/50 rounded-lg border border-purple-500/20">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-8 h-8 bg-purple-500/20 rounded-full flex items-center justify-center text-sm font-bold">5</div>
              <h3 className="font-semibold text-white">Update Dependencies</h3>
            </div>
            <code className="text-sm text-gray-300 font-mono block bg-slate-900/50 p-3 rounded">
              flutter pub add tflite_flutter riverpod sqflite<br />
              flutter pub get
            </code>
          </div>

          <div className="p-4 bg-slate-800/50 rounded-lg border border-purple-500/20">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-8 h-8 bg-purple-500/20 rounded-full flex items-center justify-center text-sm font-bold">6</div>
              <h3 className="font-semibold text-white">Test Build</h3>
            </div>
            <code className="text-sm text-gray-300 font-mono block bg-slate-900/50 p-3 rounded">
              flutter clean<br />
              flutter build apk --release
            </code>
          </div>
        </div>
      </Card>
    </div>
  );
}

function FileTree({ node, name, level }: any) {
  const [expanded, setExpanded] = useState(level < 2);
  
  if (typeof node === 'object' && node.type === 'file') {
    return (
      <div className="flex items-start gap-3 py-2 pl-4" style={{ marginLeft: `${level * 20}px` }}>
        <span className="text-lg">📄</span>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className="font-mono text-sm text-white">{name}</span>
            <Badge variant={
              node.status === 'new' ? 'success' :
              node.status === 'modify' ? 'warning' : 'neutral'
            }>
              {node.status}
            </Badge>
          </div>
          <p className="text-xs text-gray-400 mt-1">{node.description}</p>
        </div>
      </div>
    );
  }

  const hasFiles = node.files && Object.keys(node.files).length > 0;

  return (
    <div>
      <div
        className="flex items-center gap-2 py-2 cursor-pointer hover:bg-white/5 rounded px-2"
        style={{ marginLeft: `${level * 20}px` }}
        onClick={() => setExpanded(!expanded)}
      >
        <span className="text-lg">{expanded ? '📂' : '📁'}</span>
        <span className="font-mono text-sm text-purple-300 font-semibold">{name}</span>
        {hasFiles && (
          <span className="text-xs text-gray-500">
            ({Object.keys(node.files).length} items)
          </span>
        )}
      </div>
      
      {expanded && hasFiles && (
        <div>
          {Object.entries(node.files).map(([childName, childNode]: any) => (
            <FileTree key={childName} node={childNode} name={childName} level={level + 1} />
          ))}
        </div>
      )}
    </div>
  );
}
