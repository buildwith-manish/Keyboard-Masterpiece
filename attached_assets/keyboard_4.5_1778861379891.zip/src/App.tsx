import { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { AuditReport } from './components/AuditReport';
import { FeatureMatrix } from './components/FeatureMatrix';
import { ArchitectureView } from './components/ArchitectureView';
import { FileStructure } from './components/FileStructure';
import { ImplementationGuide } from './components/ImplementationGuide';
import { CodeEnhancements } from './components/CodeEnhancements';
import { PerformanceMetrics } from './components/PerformanceMetrics';
import { TestingStrategy } from './components/TestingStrategy';
import { DeploymentPackage } from './components/DeploymentPackage';

type Tab = 'audit' | 'features' | 'architecture' | 'files' | 'implementation' | 'code' | 'performance' | 'testing' | 'package';

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('audit');

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="flex h-screen overflow-hidden">
        <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
        
        <main className="flex-1 overflow-y-auto">
          <div className="p-8">
            {activeTab === 'audit' && <AuditReport />}
            {activeTab === 'features' && <FeatureMatrix />}
            {activeTab === 'architecture' && <ArchitectureView />}
            {activeTab === 'files' && <FileStructure />}
            {activeTab === 'implementation' && <ImplementationGuide />}
            {activeTab === 'code' && <CodeEnhancements />}
            {activeTab === 'performance' && <PerformanceMetrics />}
            {activeTab === 'testing' && <TestingStrategy />}
            {activeTab === 'package' && <DeploymentPackage />}
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;
